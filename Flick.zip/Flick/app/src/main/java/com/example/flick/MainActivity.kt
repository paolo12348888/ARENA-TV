package com.example.flick

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import org.json.JSONArray
import java.io.File
import kotlin.math.abs

data class Clip(val id: String, val title: String, val author: String, val uri: Uri)

class MainActivity : Activity() {

    private val coral = Color.parseColor("#FF4D6D")
    private val gold = Color.parseColor("#FFD54A")
    private val ui = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("flick", Context.MODE_PRIVATE)
    }

    private val base = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/"
    private fun s(file: String, title: String, author: String) =
        Clip(base + file, title, author, Uri.parse(base + file))

    private val samples: List<Clip> by lazy {
        listOf(
            s("ForBiggerBlazes.mp4", "Fiamme e adrenalina", "@clip.lab"),
            s("ForBiggerEscapes.mp4", "Fuga in vacanza", "@viaggiando"),
            s("ForBiggerFun.mp4", "Divertimento puro", "@fun.club"),
            s("ForBiggerJoyrides.mp4", "Giri in auto", "@motori"),
            s("ForBiggerMeltdowns.mp4", "Crisi totale", "@drama.zone"),
            s("BigBuckBunny.mp4", "Il coniglio gigante", "@animazioni"),
            s("ElephantsDream.mp4", "Il sogno dell'elefante", "@animazioni"),
            s("Sintel.mp4", "Sintel", "@animazioni"),
            s("TearsOfSteel.mp4", "Lacrime d'acciaio", "@fantascienza"),
            s("SubaruOutbackOnStreetAndDirt.mp4", "Strada e fango", "@motori"),
            s("VolkswagenGTIReview.mp4", "Prova su strada", "@motori"),
            s("WeAreGoingOnBullrun.mp4", "In viaggio", "@viaggiando"),
            s("WhatCarCanYouGetForAGrand.mp4", "Che auto con mille euro?", "@motori")
        )
    }

    private val feed = ArrayList<Clip>()
    private var index = 0
    private var favMode = false
    private var animating = false

    private lateinit var root: FrameLayout
    private lateinit var page: FrameLayout
    private lateinit var video: VideoView
    private lateinit var spinner: ProgressBar
    private lateinit var errorView: TextView
    private lateinit var emptyView: TextView
    private lateinit var titleView: TextView
    private lateinit var authorView: TextView
    private lateinit var infoBox: LinearLayout
    private lateinit var actionsBox: LinearLayout
    private lateinit var likeIcon: TextView
    private lateinit var likeCount: TextView
    private lateinit var commentCount: TextView
    private lateinit var favIcon: TextView
    private lateinit var tabForYou: TextView
    private lateinit var tabFav: TextView
    private lateinit var detector: GestureDetector

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        buildUi()
        rebuildFeed()
        showClip()
    }

    override fun onPause() {
        super.onPause()
        video.pause()
    }

    override fun onResume() {
        super.onResume()
        if (feed.isNotEmpty()) video.start()
    }

    // ---------- UI ----------

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        page = FrameLayout(this)
        video = VideoView(this)
        page.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        spinner = ProgressBar(this)
        page.addView(spinner, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        errorView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            visibility = View.GONE
        }
        page.addView(errorView, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        root.addView(page, FrameLayout.LayoutParams(-1, -1))

        emptyView = TextView(this).apply {
            text = "Nessun video salvato.\nTocca ☆ su un video per aggiungerlo ai preferiti."
            setTextColor(Color.LTGRAY)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            visibility = View.GONE
        }
        root.addView(emptyView, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        // Titolo e autore (in basso a sinistra)
        authorView = TextView(this).apply {
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        titleView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, 0)
        }
        infoBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(authorView)
            addView(titleView)
        }
        root.addView(infoBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(16), 0, dp(90), dp(84))
        })

        // Pulsanti a destra
        val like = action("♥") { toggleLike(false) }
        likeIcon = like.second; likeCount = like.third
        val comment = action("💬") { openComments() }
        commentCount = comment.third
        val fav = action("☆") { toggleFav() }
        favIcon = fav.second
        fav.third.text = "Salva"

        actionsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(like.first)
            addView(comment.first)
            addView(fav.first)
        }
        root.addView(actionsBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(12), dp(84))
        })

        // Barra in basso
        tabForYou = tab("Per te") { favMode = false; rebuildFeed(); showClip() }
        tabFav = tab("Preferiti") { favMode = true; rebuildFeed(); showClip() }
        val plus = TextView(this).apply {
            text = "＋"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(coral)
            setOnClickListener { record() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#B3000000"))
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        bar.addView(tabForYou, LinearLayout.LayoutParams(0, dp(48), 1f))
        bar.addView(plus, LinearLayout.LayoutParams(dp(64), dp(44)))
        bar.addView(tabFav, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // Video
        video.setOnPreparedListener { mp ->
            spinner.visibility = View.GONE
            mp.isLooping = true
            mp.start()
        }
        video.setOnErrorListener { _, _, _ ->
            spinner.visibility = View.GONE
            errorView.text = "Video non disponibile.\nScorri per vedere il prossimo."
            errorView.visibility = View.VISIBLE
            true
        }

        // Gesti: scorri su/giù, tocco = pausa, doppio tocco = like
        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (video.isPlaying) video.pause() else video.start()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                toggleLike(true)
                showHeart()
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (abs(dy) > dp(60) && abs(dy) > abs(dx)) {
                    go(if (dy < 0) 1 else -1)
                    return true
                }
                return false
            }
        })
        root.setOnTouchListener { _, ev -> detector.onTouchEvent(ev); true }

        setContentView(root)
    }

    private fun action(icon: String, onClick: () -> Unit): Triple<LinearLayout, TextView, TextView> {
        val iconView = TextView(this).apply {
            text = icon
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        val countView = TextView(this).apply {
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnClickListener { onClick() }
        }
        box.addView(iconView)
        box.addView(countView)
        return Triple(box, iconView, countView)
    }

    private fun tab(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setOnClickListener { onClick() }
        }

    private fun showHeart() {
        val heart = TextView(this).apply {
            text = "♥"
            textSize = 96f
            setTextColor(coral)
            alpha = 0f
            scaleX = 0.5f
            scaleY = 0.5f
        }
        root.addView(heart, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        heart.animate().alpha(1f).scaleX(1.2f).scaleY(1.2f).setDuration(180).withEndAction {
            heart.animate().alpha(0f).setDuration(320).withEndAction {
                root.removeView(heart)
            }.start()
        }.start()
    }

    // ---------- Feed ----------

    private fun mine(): List<Clip> =
        getSet("mine").sortedDescending().map { File(it) }.filter { it.exists() }.map {
            Clip(it.absolutePath, "Il mio video", "@tu", Uri.fromFile(it))
        }

    private fun rebuildFeed() {
        val all = mine() + samples
        feed.clear()
        if (favMode) {
            val f = getSet("favs")
            feed.addAll(all.filter { f.contains(it.id) })
        } else {
            feed.addAll(all)
        }
        index = 0
        tabForYou.setTextColor(if (favMode) Color.GRAY else Color.WHITE)
        tabFav.setTextColor(if (favMode) Color.WHITE else Color.GRAY)
    }

    private fun showClip() {
        errorView.visibility = View.GONE
        if (feed.isEmpty()) {
            video.stopPlayback()
            video.visibility = View.INVISIBLE
            spinner.visibility = View.GONE
            infoBox.visibility = View.GONE
            actionsBox.visibility = View.GONE
            emptyView.visibility = View.VISIBLE
            return
        }
        emptyView.visibility = View.GONE
        video.visibility = View.VISIBLE
        infoBox.visibility = View.VISIBLE
        actionsBox.visibility = View.VISIBLE
        val c = feed[index]
        authorView.text = c.author
        titleView.text = c.title
        updateActions()
        spinner.visibility = View.VISIBLE
        video.stopPlayback()
        video.setVideoURI(c.uri)
        video.start()
    }

    private fun go(delta: Int) {
        if (feed.size < 2 || animating) return
        animating = true
        val h = root.height.toFloat()
        val dir = if (delta > 0) -1f else 1f
        page.animate().translationY(dir * h).setDuration(160).withEndAction {
            index = (index + delta + feed.size) % feed.size
            showClip()
            page.translationY = -dir * h
            page.animate().translationY(0f).setDuration(160).withEndAction {
                animating = false
            }.start()
        }.start()
    }

    // ---------- Like / commenti / preferiti (salvati sul telefono) ----------

    private fun getSet(key: String): MutableSet<String> =
        HashSet(prefs.getStringSet(key, emptySet()) ?: emptySet())

    private fun putSet(key: String, v: Set<String>) {
        prefs.edit().putStringSet(key, v).apply()
    }

    private fun baseLikes(id: String): Int = 100 + abs(id.hashCode()) % 900

    private fun comments(id: String): JSONArray =
        try { JSONArray(prefs.getString("c_$id", "[]")) } catch (e: Exception) { JSONArray() }

    private fun updateActions() {
        if (feed.isEmpty()) return
        val c = feed[index]
        val liked = getSet("likes").contains(c.id)
        likeIcon.setTextColor(if (liked) coral else Color.WHITE)
        likeCount.text = (baseLikes(c.id) + (if (liked) 1 else 0)).toString()
        commentCount.text = comments(c.id).length().toString()
        val fav = getSet("favs").contains(c.id)
        favIcon.text = if (fav) "★" else "☆"
        favIcon.setTextColor(if (fav) gold else Color.WHITE)
    }

    private fun toggleLike(onlyAdd: Boolean) {
        if (feed.isEmpty()) return
        val id = feed[index].id
        val set = getSet("likes")
        if (set.contains(id)) {
            if (!onlyAdd) set.remove(id)
        } else {
            set.add(id)
        }
        putSet("likes", set)
        updateActions()
    }

    private fun toggleFav() {
        if (feed.isEmpty()) return
        val id = feed[index].id
        val set = getSet("favs")
        if (!set.remove(id)) set.add(id)
        putSet("favs", set)
        updateActions()
    }

    private fun openComments() {
        if (feed.isEmpty()) return
        val c = feed[index]
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(listBox) }
        val arr = comments(c.id)
        if (arr.length() == 0) {
            listBox.addView(TextView(this).apply {
                text = "Nessun commento. Scrivi il primo!"
                setPadding(0, dp(8), 0, dp(8))
            })
        } else {
            for (i in 0 until arr.length()) {
                listBox.addView(TextView(this).apply {
                    text = "Tu: " + arr.optString(i)
                    setPadding(0, dp(6), 0, dp(6))
                })
            }
        }
        val input = EditText(this).apply {
            hint = "Aggiungi un commento…"
            isSingleLine = true
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        box.addView(scroll, LinearLayout.LayoutParams(-1, dp(220)))
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Commenti")
            .setView(box)
            .setPositiveButton("Invia") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    val a = comments(c.id)
                    a.put(t)
                    prefs.edit().putString("c_${c.id}", a.toString()).apply()
                    updateActions()
                }
            }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    // ---------- Registra un video ----------

    private fun record() {
        try {
            startActivityForResult(Intent(MediaStore.ACTION_VIDEO_CAPTURE), 7)
        } catch (e: Exception) {
            Toast.makeText(this, "Nessuna app fotocamera trovata", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 7 || resultCode != RESULT_OK) return
        val src = data?.data ?: return
        Thread {
            try {
                val out = File(filesDir, "rec_${System.currentTimeMillis()}.mp4")
                contentResolver.openInputStream(src)!!.use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                }
                val set = getSet("mine")
                set.add(out.absolutePath)
                putSet("mine", set)
                ui.post {
                    favMode = false
                    rebuildFeed()
                    showClip()
                    Toast.makeText(this, "Video aggiunto al feed", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                ui.post {
                    Toast.makeText(this, "Impossibile salvare il video", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
