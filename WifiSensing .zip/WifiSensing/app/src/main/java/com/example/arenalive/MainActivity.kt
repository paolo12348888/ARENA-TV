package com.example.arenalive

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL

data class Channel(val name: String, val url: String, val country: String)

class MainActivity : Activity() {

    private val yellow = Color.parseColor("#F7E600")
    private val bg = Color.parseColor("#0B0B0D")
    private val card = Color.parseColor("#17171B")

    // Playlist pubbliche di canali sportivi (raccolta iptv-org). Se la prima non risponde si usa la seconda.
    private val sources = listOf(
        "https://iptv-org.github.io/iptv/categories/sports.m3u",
        "https://iptv-org.github.io/iptv/index.m3u"
    )

    private val ui = Handler(Looper.getMainLooper())
    private val all = ArrayList<Channel>()
    private val shown = ArrayList<Channel>()
    private lateinit var adapter: ChannelAdapter
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var reload: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        load()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(32, 90, 32, 16)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "ARENA LIVE"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(yellow)
        }
        reload = Button(this).apply {
            text = "Ricarica"
            setOnClickListener { load() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(reload)

        val sub = TextView(this).apply {
            text = "Sport in diretta dai canali pubblici di tutto il mondo"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 20)
        }

        search = EditText(this).apply {
            hint = "Cerca canale o paese (es. it, us, tennis)"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setBackgroundColor(card)
            setPadding(32, 28, 32, 28)
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { applyFilter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 16, 0, 12)
        }

        adapter = ChannelAdapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
            setOnItemClickListener { _, _, pos, _ ->
                val ch = shown[pos]
                startActivity(Intent(this@MainActivity, PlayerActivity::class.java).apply {
                    putExtra("name", ch.name)
                    putExtra("url", ch.url)
                })
            }
        }

        root.addView(header)
        root.addView(sub)
        root.addView(search)
        root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun load() {
        status.text = "Caricamento canali…"
        reload.isEnabled = false
        Thread {
            var result: List<Channel>? = null
            for (src in sources) {
                try {
                    val text = download(src)
                    val parsed = parse(text, onlySports = src.endsWith("index.m3u"))
                    if (parsed.isNotEmpty()) { result = parsed; break }
                } catch (e: Exception) {
                    // prova la sorgente successiva
                }
            }
            ui.post {
                reload.isEnabled = true
                if (result == null) {
                    status.text = "Impossibile caricare i canali. Controlla la connessione e premi Ricarica."
                } else {
                    all.clear(); all.addAll(result)
                    applyFilter()
                }
            }
        }.start()
    }

    private fun download(address: String): String {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    private fun parse(text: String, onlySports: Boolean): List<Channel> {
        val out = ArrayList<Channel>()
        val seen = HashSet<String>()
        val attr = Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"")
        var name = ""
        var country = ""
        var keep = true
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                val attrs = attr.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                name = line.substringAfterLast(",").trim()
                val id = attrs["tvg-id"] ?: ""
                country = if (id.contains(".")) id.substringAfterLast(".").take(2).lowercase() else ""
                val group = (attrs["group-title"] ?: "").lowercase()
                keep = !onlySports || group.contains("sport")
            } else if (line.startsWith("http") && name.isNotEmpty()) {
                if (keep && seen.add(line)) out.add(Channel(name, line, country))
                name = ""
            }
        }
        return out.sortedWith(compareBy({ it.country.ifEmpty { "zz" } }, { it.name.lowercase() }))
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(
            if (q.isEmpty()) all
            else all.filter { it.name.lowercase().contains(q) || it.country == q }
        )
        status.text = "${shown.size} canali sportivi disponibili"
        adapter.notifyDataSetChanged()
    }

    private fun flag(cc: String): String {
        if (cc.length != 2 || !cc.all { it in 'a'..'z' }) return "🌐"
        val base = 0x1F1E6
        return String(Character.toChars(base + (cc[0] - 'a'))) +
            String(Character.toChars(base + (cc[1] - 'a')))
    }

    inner class ChannelAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx: Context = this@MainActivity
            val row: LinearLayout
            val flagView: TextView
            val nameView: TextView
            val subView: TextView
            if (convertView == null) {
                row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundColor(card)
                    setPadding(32, 32, 32, 32)
                    layoutParams = AbsListViewParams()
                }
                flagView = TextView(ctx).apply { textSize = 26f; setPadding(0, 0, 28, 0) }
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                nameView = TextView(ctx).apply {
                    textSize = 16f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                }
                subView = TextView(ctx).apply { textSize = 12f; setTextColor(yellow) }
                col.addView(nameView)
                col.addView(subView)
                row.addView(flagView)
                row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.tag = arrayOf(flagView, nameView, subView)
            } else {
                row = convertView as LinearLayout
                @Suppress("UNCHECKED_CAST")
                val t = row.tag as Array<TextView>
                flagView = t[0]; nameView = t[1]; subView = t[2]
            }
            val ch = shown[position]
            flagView.text = flag(ch.country)
            nameView.text = ch.name
            subView.text = "● LIVE   ${if (ch.country.isEmpty()) "Mondo" else ch.country.uppercase()}"
            return row
        }

        private fun AbsListViewParams() =
            android.widget.AbsListView.LayoutParams(-1, -2)
    }
}
