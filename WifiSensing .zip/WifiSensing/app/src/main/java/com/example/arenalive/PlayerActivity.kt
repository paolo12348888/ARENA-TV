package com.example.arenalive

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView

class PlayerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var video: VideoView
    private lateinit var spinner: ProgressBar
    private lateinit var message: TextView
    private var started = false

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)

        val name = intent.getStringExtra("name") ?: ""
        val url = intent.getStringExtra("url") ?: ""

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        spinner = ProgressBar(this)
        root.addView(spinner, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        message = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            visibility = View.GONE
        }
        root.addView(message, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        val title = TextView(this).apply {
            text = name
            setTextColor(Color.parseColor("#F7E600"))
            textSize = 14f
            setPadding(32, 24, 32, 24)
        }
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        setContentView(root)

        val controller = MediaController(this)
        controller.setAnchorView(video)
        video.setMediaController(controller)

        video.setOnPreparedListener {
            started = true
            spinner.visibility = View.GONE
            it.start()
        }
        video.setOnErrorListener { _, _, _ ->
            showError("Questo canale non è al momento disponibile.\nTorna indietro e provane un altro.")
            true
        }

        try {
            video.setVideoURI(Uri.parse(url))
        } catch (e: Exception) {
            showError("Indirizzo del canale non valido.")
        }

        // Se dopo 25 secondi non è partito, avvisa
        ui.postDelayed({
            if (!started) showError("Il canale non risponde.\nTorna indietro e provane un altro.")
        }, 25000)
    }

    private fun showError(text: String) {
        spinner.visibility = View.GONE
        message.text = text
        message.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        video.stopPlayback()
        super.onDestroy()
    }
}
