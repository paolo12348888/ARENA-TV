package com.example.daytrader.engine

/** Lettura minimale di XML/RSS/Atom con espressioni regolari (senza dipendenze, testabile ovunque). */
object Xml {
    fun unescape(s: String): String {
        var t = s.trim()
        val cd = Regex("^<!\\[CDATA\\[(.*)]]>$", RegexOption.DOT_MATCHES_ALL).find(t)
        if (cd != null) return cd.groupValues[1].trim()
        t = Regex("&#x([0-9a-fA-F]+);").replace(t) { String(Character.toChars(it.groupValues[1].toInt(16))) }
        t = Regex("&#(\\d+);").replace(t) { String(Character.toChars(it.groupValues[1].toInt())) }
        return t.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    }

    /** Contenuto grezzo di tutti gli elementi con quel nome. */
    fun blocks(xml: String, tag: String): List<String> =
        Regex("<$tag(?:\\s[^>]*)?>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { it.groupValues[1] }.toList()

    fun text(xml: String, tag: String): String {
        val m = Regex("<$tag(?:\\s[^>]*)?>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(xml) ?: return ""
        return unescape(m.groupValues[1])
    }

    fun attr(xml: String, tag: String, attr: String): String {
        var out = ""
        for (m in Regex("<$tag\\b([^>]*)/?>").findAll(xml)) {
            val a = Regex("\\b$attr=\"([^\"]*)\"").find(m.groupValues[1])
            if (a != null) out = unescape(a.groupValues[1])
        }
        return out
    }
}
