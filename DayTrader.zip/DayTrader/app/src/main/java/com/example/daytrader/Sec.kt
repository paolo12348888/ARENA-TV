package com.example.daytrader

import com.example.daytrader.engine.EngineError
import com.example.daytrader.engine.News

/** Accesso a SEC EDGAR: richiede un User-Agent con nome ed email (impostazioni). */
object Sec {
    fun ua(store: Store): String {
        if (!store.hasSecUa()) throw EngineError("La SEC chiede di identificarti: inserisci nome ed email in Impostazioni.")
        return store.secUserAgent
    }

    fun ciks(store: Store): Map<String, String> {
        val cached = store.cikMapJson()
        if (cached != null && store.cikAge() < 7L * 24 * 3600 * 1000) {
            try { return News.cikMap(cached) } catch (e: Exception) { /* riscarica */ }
        }
        val text = Http.text(News.TICKERS_URL, ua(store))
        val map = News.cikMap(text)
        store.saveCikMapJson(text)
        return map
    }

    fun companyFacts(store: Store, cik: String): String =
        Http.text("https://data.sec.gov/api/xbrl/companyfacts/CIK$cik.json", ua(store))
}
