package com.example.daytrader.engine

import com.example.daytrader.engine.Json.dbl
import com.example.daytrader.engine.Json.list
import com.example.daytrader.engine.Json.map
import com.example.daytrader.engine.Json.str
import java.time.LocalDate
import java.time.LocalDateTime

/** Serie di un grafico Yahoo (v8) o di una risposta spark, in liste semplici. */
class Series(
    val t: List<Long>, val c: List<Double?>, val o: List<Double?>?, val h: List<Double?>?,
    val l: List<Double?>?, val v: List<Double?>?, val meta: Map<String, Any?>
)

data class UniverseResult(val kept: List<Pair<String, String>>, val counts: Map<String, Int>)
data class DailyHit(val symbol: String, val setups: List<String>, val price: Double, val closeDate: String, val rsi: Double, val volume: Long?)
data class OrbHit(
    val symbol: String, val price: Double, val at: String, val barStart: String, val barIndex: Int,
    val orHigh: Double, val orLow: Double, val pctOver: Double, val sortKey: Long
)
data class ScanCounts(val requested: Int, val fetched: Int, val scanned: Int, val hits: Int, val extra: Map<String, Int> = emptyMap())

object Scanner {
    const val BAR_MIN = 5
    const val MIN_DAILY_BARS = 30

    val SETUP_LABELS = mapOf(
        "breakout_20d" to "massimo di chiusura a 20 giorni",
        "bull_flag" to "bandiera rialzista",
        "reclaim_ma20" to "ha ripreso la media a 20 giorni",
        "oversold" to "ipervenduto (RSI sotto 30)",
        "oversold_bounce" to "rimbalzo da ipervenduto",
        "orb" to "rottura dell'opening range"
    )

    // ------------------------------------------------------------ parsing Yahoo

    private fun cols(res: Map<String, Any?>): Series {
        val q = res["indicators"].map()?.get("quote").list()?.firstOrNull().map() ?: emptyMap()
        val t = (res["timestamp"].list() ?: emptyList()).map { (it.dbl() ?: 0.0).toLong() }
        val n = t.size
        fun col(k: String): List<Double?>? {
            val v = q[k].list() ?: return null
            return List(n) { i -> v.getOrNull(i).dbl() }
        }
        return Series(t, col("close") ?: List(n) { null }, col("open"), col("high"), col("low"), col("volume"), res["meta"].map() ?: emptyMap())
    }

    fun parseSpark(text: String): Map<String, Series> {
        val doc = Json.parse(text).map()
        val sp = doc?.get("spark").map() ?: throw EngineError("Risposta spark di Yahoo non riconosciuta")
        val out = LinkedHashMap<String, Series>()
        for (item in sp["result"].list() ?: emptyList()) {
            val m = item.map() ?: continue
            val resp = m["response"].list()?.firstOrNull().map() ?: continue
            val ysym = (m["symbol"].str() ?: resp["meta"].map()?.get("symbol").str() ?: "").uppercase()
            out[ysym.replace("-", ".")] = cols(resp)
        }
        if (out.isEmpty()) {
            val err = sp["error"].map()
            if (err != null) throw EngineError("Yahoo spark: " + (err["description"].str() ?: err["code"].str() ?: "errore"))
        }
        return out
    }

    fun parseChartSeries(text: String, sym: String = ""): Series {
        val doc = try { Json.parse(text).map() } catch (e: Exception) { null }
        val chart = doc?.get("chart").map() ?: throw EngineError("Yahoo ha restituito qualcosa di inatteso per $sym")
        val res = chart["result"].list()?.firstOrNull().map()
            ?: throw EngineError("Nessun dato per $sym: " + (chart["error"].map()?.get("description").str() ?: "simbolo sconosciuto"))
        return cols(res)
    }

    // ------------------------------------------------------------ universo (Nasdaq Trader)

    private val TICKER = Regex("^[A-Z]{1,5}$|^[A-Z]{1,4}\\.[A-Z]$")
    private val ALWAYS_OUT = listOf(
        "warrant" to Regex("\\bwarrants?\\b"),
        "unit or right" to Regex("\\b(units?|rights?),? (each|that|entitling)\\b|(?<!the )\\brights? to\\b"),
        "note" to Regex("\\b(notes?|etns?|debentures?)\\b"),
        "coupon" to Regex("%"),
        "depositary" to Regex("(?<!american )(?<!global )\\bdepositary shares?\\b")
    )
    private val COMMON = Regex(
        "\\bcommon (stock|shares?|units?)\\b|\\bord(inary)? shares?\\b|\\bshares? of beneficial interest\\b" +
            "|\\b(american|global) deposit[ao]ry\\b|\\bads[s]?\\b|\\badrs?\\b" +
            "|\\b(limited partnership|partnership|trust) units?\\b|\\bl\\.?p\\.? units?\\b" +
            "|\\bunits? (of|representing)\\b.*\\b(limited partner|partnership|beneficial interest|limited liability)"
    )
    private val SOFT_OUT = listOf(
        "unit" to Regex("\\bunits?\\b"), "right" to Regex("\\brights?\\b"),
        "bond" to Regex("\\bbonds?\\b"), "preferred" to Regex("\\bpreferred\\b|\\bpreference\\b")
    )

    fun classify(row: Map<String, String>): String {
        val sym = (row["Symbol"] ?: row["ACT Symbol"] ?: "").trim()
        if ((row["Test Issue"] ?: "").trim() != "N") return "test issue"
        if ((row["ETF"] ?: "").trim() != "N") return "ETF"
        if ((row["NextShares"] ?: "N").trim() != "N") return "NextShares"
        if (!TICKER.matches(sym)) return "not a plain ticker"
        if (Regex("\\.[UWR]$").containsMatchIn(sym)) return "unit / warrant / right suffix"
        val name = (row["Security Name"] ?: "").lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ")
        for ((tag, rx) in ALWAYS_OUT) if (rx.containsMatchIn(name)) return tag
        if (COMMON.containsMatchIn(name)) return "keep"
        for ((tag, rx) in SOFT_OUT) if (rx.containsMatchIn(name)) return tag
        return "keep"
    }

    fun parseSymdir(text: String): List<Map<String, String>> {
        val lines = text.replace("\r", "").split("\n").filter { it.isNotBlank() }
        if (lines.isEmpty() || !lines[0].contains("|")) throw EngineError("Non è un elenco di simboli Nasdaq Trader")
        val hdr = lines[0].split("|").map { it.trim() }
        if ("Security Name" !in hdr || ("Symbol" !in hdr && "ACT Symbol" !in hdr)) throw EngineError("Intestazione dell'elenco non riconosciuta")
        val rows = ArrayList<Map<String, String>>()
        for (ln in lines.drop(1)) {
            if (ln.startsWith("File Creation Time")) continue
            val parts = ln.split("|")
            val m = LinkedHashMap<String, String>()
            for (i in hdr.indices) if (i < parts.size) m[hdr[i]] = parts[i]
            rows.add(m)
        }
        return rows
    }

    fun buildUniverse(texts: List<String>): UniverseResult {
        val kept = java.util.TreeMap<String, String>()
        val counts = LinkedHashMap<String, Int>()
        for (text in texts) {
            for (r in parseSymdir(text)) {
                counts["rows"] = (counts["rows"] ?: 0) + 1
                val why = classify(r)
                counts[why] = (counts[why] ?: 0) + 1
                if (why == "keep") {
                    val sym = (r["Symbol"] ?: r["ACT Symbol"] ?: "").trim()
                    kept[sym] = (r["Security Name"] ?: "").trim().split(Regex("\\s+")).joinToString(" ")
                }
            }
        }
        return UniverseResult(kept.entries.map { Pair(it.key, it.value) }, counts)
    }

    // ------------------------------------------------------------ setup sui prezzi giornalieri

    fun rsi(c: List<Double>, n: Int = 14): Double? {
        if (c.size < n + 1) return null
        val g = (1 until c.size).map { maxOf(0.0, c[it] - c[it - 1]) }
        val lo = (1 until c.size).map { maxOf(0.0, c[it - 1] - c[it]) }
        var ag = g.take(n).sum() / n
        var al = lo.take(n).sum() / n
        for (i in n until g.size) {
            ag = (ag * (n - 1) + g[i]) / n
            al = (al * (n - 1) + lo[i]) / n
        }
        return if (al != 0.0) 100 - 100 / (1 + ag / al) else 100.0
    }

    fun dailyCloses(s: Series, nowNy: LocalDateTime): List<Pair<LocalDate, Double>> {
        val today = nowNy.toLocalDate()
        val closed = TimeUtil.closedReason(today) != null
        val todayDone = closed || TimeUtil.minutesOf(nowNy) >= TimeUtil.closeMin(today.toString())
        val out = java.util.TreeMap<LocalDate, Double>()
        for (i in s.t.indices) {
            val c = s.c[i] ?: continue
            val d = TimeUtil.toNy(s.t[i]).toLocalDate()
            if (d.isAfter(today) || (d == today && !todayDone)) continue
            out[d] = c
        }
        return out.entries.map { Pair(it.key, it.value) }
    }

    data class Setups(val tags: List<String>, val rsi: Double?)

    fun findSetups(c: List<Double>): Setups {
        val last = c.last()
        val hi20 = c.subList(c.size - 21, c.size - 1).max()
        val ma20 = c.takeLast(20).average()
        val ma20Prev = c.subList(c.size - 21, c.size - 1).average()
        val run = c[c.size - 6] / c[c.size - 16] - 1
        val rng5 = (c.takeLast(5).max() - c.takeLast(5).min()) / last
        val r = rsi(c)
        val rPrev = rsi(c.dropLast(1))
        val tags = ArrayList<String>()
        if (last > hi20) tags.add("breakout_20d")
        if (run > 0.10 && rng5 < 0.05) tags.add("bull_flag")
        if (c[c.size - 2] < ma20Prev && last > ma20) tags.add("reclaim_ma20")
        if (r != null && r < 30) tags.add("oversold")
        if (rPrev != null && rPrev < 30 && last > c[c.size - 2]) tags.add("oversold_bounce")
        return Setups(tags, r)
    }

    fun scanDaily(data: Map<String, Series>, symbols: List<String>, nowNy: LocalDateTime, minPrice: Double, minVolume: Long): Pair<List<DailyHit>, ScanCounts> {
        val hits = ArrayList<DailyHit>()
        var fetched = 0; var illiquid = 0; var short = 0; var scanned = 0
        for (sym in symbols) {
            val s = data[sym] ?: continue
            fetched++
            val bars = dailyCloses(s, nowNy)
            var price = s.meta["regularMarketPrice"].dbl()
            if (price == null && bars.isNotEmpty()) price = bars.last().second
            val vol = s.meta["regularMarketVolume"].dbl()
            if (price == null || price < minPrice || (minVolume > 0 && (vol == null || vol < minVolume))) { illiquid++; continue }
            if (bars.size < MIN_DAILY_BARS) { short++; continue }
            scanned++
            val closes = bars.map { it.second }
            val st = findSetups(closes)
            if (st.tags.isNotEmpty()) {
                hits.add(DailyHit(sym, st.tags, Num.pyRound2(closes.last()), bars.last().first.toString(), Num.pyRound(st.rsi ?: 0.0, 1), vol?.toLong()))
            }
        }
        hits.sortWith(compareBy<DailyHit>({ -(it.price * (it.volume ?: 0L)) }, { it.symbol }))
        return Pair(hits, ScanCounts(symbols.size, fetched, scanned, hits.size, mapOf("illiquidi" to illiquid, "corti" to short)))
    }

    // ------------------------------------------------------------ opening range breakout

    class SBar(val start: LocalDateTime, val c: Double, val h: Double?, val l: Double?, val v: Double)

    fun slot(day: LocalDate, k: Int): LocalDateTime = day.atTime(9, 30).plusMinutes((BAR_MIN * k).toLong())

    fun sessionBars(s: Series, day: LocalDate, cutoff: LocalDateTime): List<SBar> {
        val closeMin = TimeUtil.closeMin(day.toString())
        val out = java.util.TreeMap<LocalDateTime, SBar>()
        for (i in s.t.indices) {
            val c = s.c[i] ?: continue
            val et = TimeUtil.toNy(s.t[i])
            if (et.toLocalDate() != day || et.second != 0 || et.minute % BAR_MIN != 0) continue
            val m = TimeUtil.minutesOf(et)
            if (m < TimeUtil.OPEN_MIN || m >= closeMin) continue
            if (et.plusMinutes(BAR_MIN.toLong()).isAfter(cutoff)) continue
            out[et] = SBar(et, c, s.h?.get(i), s.l?.get(i), s.v?.get(i) ?: 0.0)
        }
        return out.values.toList()
    }

    fun usable(bars: List<SBar>, day: LocalDate, cutoff: LocalDateTime, nRange: Int): Boolean {
        val minsToCutoff = java.time.Duration.between(slot(day, 0), cutoff).toMinutes()
        var want = (minsToCutoff / BAR_MIN).toInt()
        val minsToClose = (TimeUtil.closeMin(day.toString()) - TimeUtil.OPEN_MIN)
        want = minOf(want, minsToClose / BAR_MIN)
        if (want < nRange || bars.size != want) return false
        return bars.withIndex().all { (k, b) -> b.start == slot(day, k) }
    }

    fun orbCandidate(bars: List<SBar>, nRange: Int): Boolean {
        val top = bars.take(nRange).maxOf { it.c }
        return bars.drop(nRange).any { it.c >= top }
    }

    fun orbHit(sym: String, bars: List<SBar>, nRange: Int): OrbHit? {
        val rng = bars.take(nRange)
        if (rng.any { it.h == null || it.l == null }) return null
        val oh = rng.maxOf { it.h!! }
        val ol = rng.minOf { it.l!! }
        for (k in nRange until bars.size) {
            val b = bars[k]
            if (b.c > oh) {
                val closesAt = b.start.plusMinutes(BAR_MIN.toLong())
                return OrbHit(sym, Num.pyRound2(b.c), TimeUtil.clock12(TimeUtil.minutesOf(closesAt)), "%02d:%02d".format(b.start.hour, b.start.minute), k,
                    Num.pyRound2(oh), Num.pyRound2(ol), Num.pyRound((b.c / oh - 1) * 100, 2), TimeUtil.epochOf(closesAt))
            }
        }
        return null
    }

    /** stage1: closes (spark o v8). confirm(sym): serie v8 con massimi e minimi (null = usa stage1). */
    fun scanOrb(
        stage1: Map<String, Series>, symbols: List<String>, day: LocalDate, cutoff: LocalDateTime, orMinutes: Int,
        minPrice: Double = 0.0, minVolume: Double = 0.0, confirm: ((String) -> Series?)? = null, maxConfirm: Int = 200
    ): Triple<List<OrbHit>, ScanCounts, Map<String, String>> {
        val nRange = orMinutes / BAR_MIN
        var fetched = 0; var unusable = 0; var illiquid = 0; var scanned = 0; var unconfirmed = 0; var confirmed = 0
        val cands = ArrayList<Triple<String, List<SBar>, Double>>()
        for (sym in symbols) {
            val s = stage1[sym] ?: continue
            fetched++
            val bars = sessionBars(s, day, cutoff)
            if (!usable(bars, day, cutoff, nRange)) { unusable++; continue }
            val vol = if (s.v != null) bars.sumOf { it.v } else (s.meta["regularMarketVolume"].dbl() ?: 0.0)
            if (bars.last().c < minPrice || vol < minVolume) { illiquid++; continue }
            scanned++
            if (orbCandidate(bars, nRange)) cands.add(Triple(sym, bars, bars.last().c * vol))
        }
        val nCands = cands.size
        var work: List<Triple<String, List<SBar>, Double>> = cands
        if (confirm != null && maxConfirm > 0 && cands.size > maxConfirm) {
            work = cands.sortedByDescending { it.third }.take(maxConfirm)
            unconfirmed = cands.size - maxConfirm
        }
        val hits = ArrayList<OrbHit>()
        val failed = LinkedHashMap<String, String>()
        for ((sym, bars, _) in work) {
            var full = bars
            if (confirm != null) {
                val s2 = try { confirm(sym) } catch (e: EngineError) { failed[sym] = e.message ?: "errore"; continue }
                if (s2 != null) {
                    full = sessionBars(s2, day, cutoff)
                    if (!usable(full, day, cutoff, nRange)) { failed[sym] = "manca una candela nel grafico"; continue }
                }
            }
            confirmed++
            orbHit(sym, full, nRange)?.let { hits.add(it) }
        }
        hits.sortWith(compareBy<OrbHit>({ it.sortKey }, { it.symbol }))
        return Triple(hits, ScanCounts(symbols.size, fetched, scanned, hits.size, mapOf("non utilizzabili" to unusable, "illiquidi" to illiquid, "candidati" to nCands, "confermati" to confirmed, "non confermati" to unconfirmed)), failed)
    }

    /** Controlla che la finestra per la scansione ORB abbia senso; ritorna (giorno, cutoff) o lancia l'errore con il motivo. */
    fun orbWindow(nowNy: LocalDateTime, at: Int?, orMinutes: Int, noAfter: Int?, explicitDay: LocalDate? = null): Pair<LocalDate, LocalDateTime> {
        val day = explicitDay ?: nowNy.toLocalDate()
        if (orMinutes < BAR_MIN || orMinutes % BAR_MIN != 0 || orMinutes > 120) throw EngineError("L'opening range deve essere un multiplo di 5 minuti tra 5 e 120 (15 è il classico).")
        val closed = TimeUtil.closedReason(day)
        if (closed != null) throw EngineError("Nessuna sessione il $day ($closed): il mercato è chiuso.")
        val closeDt = day.atTime(TimeUtil.closeMin(day.toString()) / 60, TimeUtil.closeMin(day.toString()) % 60)
        val rangeEnd = slot(day, orMinutes / BAR_MIN)
        val firstClose = rangeEnd.plusMinutes(BAR_MIN.toLong())
        val cutoff: LocalDateTime
        if (at != null) {
            cutoff = day.atTime(at / 60, at % 60)
            if (explicitDay == null && cutoff.isAfter(nowNy.plusSeconds(59))) throw EngineError("L'orario scelto è nel futuro.")
            if (cutoff.isAfter(closeDt)) throw EngineError("L'orario scelto è dopo la chiusura.")
        } else {
            cutoff = nowNy.withSecond(0).withNano(0)
            if (!cutoff.isBefore(closeDt)) throw EngineError("Il mercato è chiuso (chiusura alle ${TimeUtil.clock12(TimeUtil.minutesOf(closeDt))} di New York). Scegli un orario del giorno, per esempio 10:15.")
        }
        if (cutoff.isBefore(firstClose)) throw EngineError("A New York sono le ${TimeUtil.clock12(TimeUtil.minutesOf(cutoff))}: l'opening range di $orMinutes minuti va dalle 9:30 alle ${TimeUtil.clock12(TimeUtil.minutesOf(rangeEnd))} e la prima candela dopo chiude alle ${TimeUtil.clock12(TimeUtil.minutesOf(firstClose))}. Riprova dopo.")
        if (noAfter != null && TimeUtil.minutesOf(cutoff) > noAfter) throw EngineError("Dopo le ${TimeUtil.clock24(noAfter)} (ultimo orario per nuovi ingressi) una rottura trovata ora sarebbe scaduta.")
        return Pair(day, cutoff)
    }
}
