package com.example.daytrader.engine

/**
 * Generatore Mersenne Twister identico a random.Random(seed) di Python:
 * stesso seme, stessi numeri del repository originale.
 */
class PyRandom(seed: Int) {
    private val mt = IntArray(624)
    private var idx = 625

    init {
        initByArray(intArrayOf(Math.abs(seed)))
    }

    private fun initGenrand(s: Int) {
        mt[0] = s
        for (i in 1 until 624) {
            val prev = mt[i - 1]
            mt[i] = 1812433253 * (prev xor (prev ushr 30)) + i
        }
        idx = 624
    }

    private fun initByArray(key: IntArray) {
        initGenrand(19650218)
        var i = 1
        var j = 0
        var k = if (624 > key.size) 624 else key.size
        while (k > 0) {
            val prev = mt[i - 1]
            mt[i] = (mt[i] xor ((prev xor (prev ushr 30)) * 1664525)) + key[j] + j
            i++; j++
            if (i >= 624) { mt[0] = mt[623]; i = 1 }
            if (j >= key.size) j = 0
            k--
        }
        k = 623
        while (k > 0) {
            val prev = mt[i - 1]
            mt[i] = (mt[i] xor ((prev xor (prev ushr 30)) * 1566083941)) - i
            i++
            if (i >= 624) { mt[0] = mt[623]; i = 1 }
            k--
        }
        mt[0] = 0x80000000.toInt()
        idx = 624
    }

    private fun nextInt32(): Int {
        if (idx >= 624) {
            for (kk in 0 until 624) {
                val y = (mt[kk] and 0x80000000.toInt()) or (mt[(kk + 1) % 624] and 0x7fffffff)
                var v = mt[(kk + 397) % 624] xor (y ushr 1)
                if (y and 1 != 0) v = v xor 0x9908b0df.toInt()
                mt[kk] = v
            }
            idx = 0
        }
        var y = mt[idx++]
        y = y xor (y ushr 11)
        y = y xor ((y shl 7) and 0x9d2c5680.toInt())
        y = y xor ((y shl 15) and 0xefc60000.toInt())
        y = y xor (y ushr 18)
        return y
    }

    private fun getRandBits(k: Int): Int = nextInt32() ushr (32 - k)

    /** _randbelow di Python: numero intero in [0, n). */
    fun randBelow(n: Int): Int {
        if (n <= 0) return 0
        val k = 32 - Integer.numberOfLeadingZeros(n)
        var r = getRandBits(k)
        while (r >= n) r = getRandBits(k)
        return r
    }

    /** randint(a, b) incluso. */
    fun randInt(a: Int, b: Int): Int = a + randBelow(b + 1 - a)
}
