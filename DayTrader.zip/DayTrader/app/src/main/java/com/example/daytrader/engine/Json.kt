package com.example.daytrader.engine

/** Parser JSON minimale (nessuna dipendenza): numeri come Double, oggetti come Map, array come List. */
object Json {
    fun parse(text: String): Any? {
        val p = P(text)
        p.ws()
        val v = p.value()
        p.ws()
        if (p.i != text.length) throw IllegalArgumentException("JSON: testo extra alla posizione ${p.i}")
        return v
    }

    /** Serializza Map, List, String, numeri, Boolean e null. */
    fun write(v: Any?): String {
        val sb = StringBuilder()
        w(v, sb)
        return sb.toString()
    }

    private fun w(v: Any?, sb: StringBuilder) {
        when (v) {
            null -> sb.append("null")
            is String -> {
                sb.append('"')
                for (c in v) when (c) {
                    '"' -> sb.append("\\\"")
                    '\\' -> sb.append("\\\\")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
                }
                sb.append('"')
            }
            is Boolean -> sb.append(v.toString())
            is Double -> if (v == Math.floor(v) && Math.abs(v) < 1e15) sb.append(v.toLong()) else sb.append(v)
            is Number -> sb.append(v.toString())
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    w(k.toString(), sb); sb.append(':'); w(x, sb)
                }
                sb.append('}')
            }
            is List<*> -> {
                sb.append('[')
                for ((i, x) in v.withIndex()) {
                    if (i > 0) sb.append(',')
                    w(x, sb)
                }
                sb.append(']')
            }
            else -> w(v.toString(), sb)
        }
    }

    private class P(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            if (i >= s.length) throw IllegalArgumentException("JSON: fine inattesa")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw IllegalArgumentException("JSON: carattere '$c' a $i")
            }
        }
        fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) throw IllegalArgumentException("JSON: valore non valido a $i")
            i += w.length
            return v
        }
        fun num(): Double {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            return s.substring(st, i).toDouble()
        }
        fun str(): String {
            i++
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw IllegalArgumentException("JSON: stringa non chiusa")
                val c = s[i++]
                if (c == '"') break
                if (c == '\\') {
                    when (val e = s[i++]) {
                        '"' -> sb.append('"')
                        '\\' -> sb.append('\\')
                        '/' -> sb.append('/')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000c')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                        else -> sb.append(e)
                    }
                } else sb.append(c)
            }
            return sb.toString()
        }
        fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            ws()
            if (s[i] == ']') { i++; return out }
            while (true) {
                ws(); out.add(value()); ws()
                val c = s[i++]
                if (c == ']') break
                if (c != ',') throw IllegalArgumentException("JSON: atteso ',' o ']' a $i")
            }
            return out
        }
        fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            ws()
            if (s[i] == '}') { i++; return out }
            while (true) {
                ws()
                val k = str()
                ws()
                if (s[i++] != ':') throw IllegalArgumentException("JSON: atteso ':' a $i")
                ws()
                out[k] = value()
                ws()
                val c = s[i++]
                if (c == '}') break
                if (c != ',') throw IllegalArgumentException("JSON: atteso ',' o '}' a $i")
            }
            return out
        }
    }

    // piccoli aiuti per leggere strutture annidate
    @Suppress("UNCHECKED_CAST")
    fun Any?.map(): Map<String, Any?>? = this as? Map<String, Any?>
    @Suppress("UNCHECKED_CAST")
    fun Any?.list(): List<Any?>? = this as? List<Any?>
    fun Any?.dbl(): Double? = (this as? Double)
    fun Any?.str(): String? = this as? String
}
