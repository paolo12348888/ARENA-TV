package com.example.daytrader

import android.content.Context
import android.content.SharedPreferences
import com.example.daytrader.engine.AlertRule
import com.example.daytrader.engine.Config
import com.example.daytrader.engine.Json
import com.example.daytrader.engine.Json.dbl
import com.example.daytrader.engine.Json.list
import com.example.daytrader.engine.Json.map
import com.example.daytrader.engine.Json.str
import com.example.daytrader.engine.LedgerEntry

/** Tutto ciò che l'app ricorda, salvato sul telefono (SharedPreferences). */
class Store(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("daytrader", Context.MODE_PRIVATE)

    companion object {
        val DEFAULT_WATCH = listOf(
            "AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "TSLA", "AMD", "NFLX", "AVGO", "JPM", "BAC", "WFC", "XOM",
            "CVX", "PFE", "KO", "PEP", "WMT", "HD", "DIS", "INTC", "CSCO", "ORCL", "CRM", "ADBE", "QCOM", "MU", "PLTR",
            "SOFI", "RIVN", "F", "GM", "AAL", "CCL", "UBER", "SHOP", "COIN", "SNAP", "PYPL"
        )
    }

    // ---- impostazioni
    fun config(): Config {
        val m = try { Json.parse(sp.getString("cfg", "{}") ?: "{}").map() ?: emptyMap() } catch (e: Exception) { emptyMap() }
        val d = Config()
        return Config(
            budget = m["budget"].dbl() ?: d.budget,
            cashBufferPct = m["cashBufferPct"].dbl() ?: d.cashBufferPct,
            maxPositionPct = m["maxPositionPct"].dbl() ?: d.maxPositionPct,
            maxOrderUsd = m["maxOrderUsd"].dbl() ?: d.maxOrderUsd,
            minOrderUsd = m["minOrderUsd"].dbl() ?: d.minOrderUsd,
            maxLossPerTrade = m["maxLossPerTrade"].dbl() ?: d.maxLossPerTrade,
            maxDailyLoss = m["maxDailyLoss"].dbl() ?: d.maxDailyLoss,
            maxTradesPerDay = (m["maxTradesPerDay"].dbl() ?: d.maxTradesPerDay.toDouble()).toInt(),
            minRewardRisk = m["minRewardRisk"].dbl() ?: d.minRewardRisk,
            noEntriesBefore = m["noEntriesBefore"].str() ?: d.noEntriesBefore,
            noEntriesAfter = m["noEntriesAfter"].str() ?: d.noEntriesAfter,
            flatBy = m["flatBy"].str() ?: d.flatBy,
            blocked = (m["blocked"].list() ?: emptyList()).mapNotNull { it.str() },
            pdtGuard = (m["pdtGuard"] as? Boolean) ?: d.pdtGuard
        )
    }

    fun saveConfig(c: Config) {
        val m = linkedMapOf<String, Any?>(
            "budget" to c.budget, "cashBufferPct" to c.cashBufferPct, "maxPositionPct" to c.maxPositionPct,
            "maxOrderUsd" to c.maxOrderUsd, "minOrderUsd" to c.minOrderUsd, "maxLossPerTrade" to c.maxLossPerTrade,
            "maxDailyLoss" to c.maxDailyLoss, "maxTradesPerDay" to c.maxTradesPerDay.toDouble(), "minRewardRisk" to c.minRewardRisk,
            "noEntriesBefore" to c.noEntriesBefore, "noEntriesAfter" to c.noEntriesAfter, "flatBy" to c.flatBy,
            "blocked" to c.blocked, "pdtGuard" to c.pdtGuard
        )
        sp.edit().putString("cfg", Json.write(m)).apply()
    }

    var secUserAgent: String
        get() = sp.getString("ua", "") ?: ""
        set(v) { sp.edit().putString("ua", v.trim()).apply() }

    fun hasSecUa(): Boolean = secUserAgent.contains("@") && !secUserAgent.contains("you@example.com")

    var watchlist: List<String>
        get() {
            val s = sp.getString("watch", null) ?: return DEFAULT_WATCH
            return s.split(",", " ", "\n").map { it.trim().uppercase() }.filter { it.isNotEmpty() }.distinct()
        }
        set(v) { sp.edit().putString("watch", v.joinToString(",")).apply() }

    // ---- avvisi
    fun rules(): List<AlertRule> {
        val l = try { Json.parse(sp.getString("rules", "[]") ?: "[]").list() ?: emptyList() } catch (e: Exception) { emptyList() }
        return l.mapNotNull { x ->
            val m = x.map() ?: return@mapNotNull null
            AlertRule(
                id = m["id"].str() ?: return@mapNotNull null, type = m["type"].str() ?: return@mapNotNull null,
                symbol = m["symbol"].str() ?: "", price = m["price"].dbl(), pct = m["pct"].dbl(),
                direction = m["direction"].str() ?: "", at = m["at"].str() ?: "", beforeClose = (m["beforeClose"] as? Boolean) ?: false,
                date = m["date"].str() ?: "", label = m["label"].str() ?: "", note = m["note"].str() ?: "",
                rearm = (m["rearm"] as? Boolean) ?: false, ref = m["ref"].dbl()
            )
        }
    }

    fun saveRules(rules: List<AlertRule>) {
        val l = rules.map { r ->
            linkedMapOf<String, Any?>(
                "id" to r.id, "type" to r.type, "symbol" to r.symbol, "price" to r.price, "pct" to r.pct,
                "direction" to r.direction, "at" to r.at, "beforeClose" to r.beforeClose, "date" to r.date,
                "label" to r.label, "note" to r.note, "rearm" to r.rearm, "ref" to r.ref
            )
        }
        sp.edit().putString("rules", Json.write(l)).apply()
    }

    fun alertState(): Map<String, String> {
        val m = try { Json.parse(sp.getString("alertState", "{}") ?: "{}").map() ?: emptyMap() } catch (e: Exception) { emptyMap() }
        return m.mapNotNull { (k, v) -> (v as? String)?.let { k to it } }.toMap()
    }

    fun saveAlertState(s: Map<String, String>) {
        sp.edit().putString("alertState", Json.write(s)).apply()
    }

    var monitoring: Boolean
        get() = sp.getBoolean("monitor", false)
        set(v) { sp.edit().putBoolean("monitor", v).apply() }

    // ---- operazioni registrate (limiti giornalieri)
    fun ledger(): List<LedgerEntry> {
        val l = try { Json.parse(sp.getString("ledger", "[]") ?: "[]").list() ?: emptyList() } catch (e: Exception) { emptyList() }
        return l.mapNotNull { x ->
            val m = x.map() ?: return@mapNotNull null
            LedgerEntry(m["date"].str() ?: return@mapNotNull null, m["symbol"].str() ?: "", m["maxLoss"].dbl() ?: 0.0, (m["opened"] as? Boolean) ?: true)
        }
    }

    fun addLedger(e: LedgerEntry) {
        val all = ledger().filter { it.date >= java.time.LocalDate.now().minusDays(30).toString() } + e
        val l = all.map { linkedMapOf<String, Any?>("date" to it.date, "symbol" to it.symbol, "maxLoss" to it.maxLoss, "opened" to it.opened) }
        sp.edit().putString("ledger", Json.write(l)).apply()
    }

    fun clearLedger() { sp.edit().remove("ledger").apply() }

    // ---- cache SEC (ticker -> CIK)
    fun cikMapJson(): String? = sp.getString("ciks", null)
    fun saveCikMapJson(s: String) { sp.edit().putString("ciks", s).putLong("ciksAt", System.currentTimeMillis()).apply() }
    fun cikAge(): Long = System.currentTimeMillis() - sp.getLong("ciksAt", 0L)
}
