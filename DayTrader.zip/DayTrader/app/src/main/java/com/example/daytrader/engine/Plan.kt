package com.example.daytrader.engine

/** Piano di uscita: stop e target decisi PRIMA di entrare (porting di trader-exit). */
data class ExitPlan(
    val symbol: String, val entry: Double, val stop: Double, val target: Double,
    val stopRule: String, val stopLabel: String, val targetR: Double, val targetLabel: String,
    val risk: Double, val rewardRisk: Double, val orHigh: Double?, val orLow: Double?,
    val orMinutes: Int, val flatBy: String, val date: String, val entryBar: Int, val entryTime: String,
    val setup: String
)

object Planner {
    const val MIN_RISK_PCT = 0.05
    const val ATR_BARS = 14

    fun atrOf(bars: List<Bar>, n: Int = ATR_BARS): Pair<Double, Int> {
        val trs = ArrayList<Double>()
        var prev: Double? = null
        for (b in bars) {
            var tr = b.h - b.l
            if (prev != null) tr = maxOf(tr, Math.abs(b.h - prev), Math.abs(b.l - prev))
            trs.add(tr)
            prev = b.c
        }
        val use = trs.takeLast(n)
        return Pair(use.sum() / use.size, use.size)
    }

    /**
     * stopRule: or_mid | or_low | price | pct | atr   stopParam: prezzo, percentuale o K dell'ATR
     * targetRule: r | price   targetParam: multiplo di R o prezzo
     */
    fun compute(
        symbol: String, entry: Double, stopRule: String, stopParam: Double?, targetRule: String, targetParam: Double,
        orHigh: Double?, orLow: Double?, atr: Pair<Double, Int>? = null, orMinutes: Int = 15,
        flatBy: String = "15:55", date: String = "", entryBar: Int = 0, entryTime: String = "", setup: String = "orb"
    ): ExitPlan {
        val e = Num.cents(entry)
        if (e <= 0) throw EngineError("Il prezzo di ingresso deve essere sopra 0 $.")
        val raw: Double
        val label: String
        when (stopRule) {
            "or_mid", "or_low" -> {
                if (orHigh == null || orLow == null) throw EngineError("Lo stop sull'opening range richiede massimo e minimo del range.")
                val oh = Num.cents(orHigh); val ol = Num.cents(orLow)
                if (oh <= ol) throw EngineError("Il massimo del range ($oh) deve stare sopra il minimo ($ol).")
                if (stopRule == "or_mid") { raw = (oh + ol) / 2; label = "metà dell'opening range" }
                else { raw = ol; label = "minimo dell'opening range" }
            }
            "price" -> { raw = stopParam ?: throw EngineError("Serve il prezzo dello stop."); label = "prezzo scelto da te" }
            "pct" -> {
                val p = stopParam ?: throw EngineError("Serve la percentuale dello stop.")
                raw = e * (1 - p / 100); label = "%s%% sotto l'ingresso".format(trim(p))
            }
            "atr" -> {
                val k = stopParam ?: throw EngineError("Serve il moltiplicatore ATR.")
                val a = atr ?: throw EngineError("Lo stop ATR richiede le candele della sessione.")
                raw = e - k * Num.pyRound(a.first, 6); label = "%s x ATR(%d) sotto l'ingresso".format(trim(k), a.second)
            }
            else -> throw EngineError("Regola di stop sconosciuta: $stopRule")
        }
        val stop = Num.floorCents(raw)
        if (stop >= e) throw EngineError("Lo stop $stop ($label) è uguale o sopra l'ingresso $e: in un acquisto lo stop va sotto.")
        if (stop <= 0) throw EngineError("Lo stop viene $stop: scegli uno stop sopra 0 $.")
        val risk = Num.cents(e - stop)
        val floorRisk = e * MIN_RISK_PCT / 100
        if (risk < floorRisk - 1e-9) {
            throw EngineError("Lo stop è a %.2f $ dall'ingresso, meno dello 0,05%% del prezzo: troppo stretto, il normale ondeggiare lo farebbe scattare. Allargalo.".format(risk))
        }
        val target: Double
        val tLabel: String
        val tr: Double
        if (targetRule == "r") {
            target = Num.cents(e + targetParam * risk); tLabel = "%sR (%s volte il rischio)".format(trim(targetParam), trim(targetParam)); tr = targetParam
        } else {
            target = Num.cents(targetParam)
            tr = Num.cents((target - e) / risk)
            tLabel = "prezzo scelto da te (%sR)".format(trim(tr))
        }
        if (target <= e) throw EngineError("Il target $target è uguale o sotto l'ingresso $e: in un acquisto il target va sopra.")
        val rr = Num.cents((target - e) / risk)
        return ExitPlan(
            symbol.uppercase(), e, stop, target, stopRule, label, tr, tLabel, risk, rr,
            orHigh, orLow, orMinutes, flatBy, date, entryBar, entryTime, setup
        )
    }

    private fun trim(x: Double): String = if (x == Math.floor(x)) x.toLong().toString() else x.toString()
}
