package com.example.daytrader.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Ventaglio della Time Machine: fasce 5-95 e 25-75, mediana e le linee di entrata, stop e target. */
class FanChartView(ctx: Context) : View(ctx) {
    private var bands: List<List<Double>> = emptyList()
    private var entry = 0.0
    private var stop = 0.0
    private var target = 0.0
    private val fillOuter = Paint().apply { color = Color.parseColor("#33607D8B"); style = Paint.Style.FILL; isAntiAlias = true }
    private val fillInner = Paint().apply { color = Color.parseColor("#55607D8B"); style = Paint.Style.FILL; isAntiAlias = true }
    private val median = Paint().apply { color = Color.WHITE; strokeWidth = 4f; style = Paint.Style.STROKE; isAntiAlias = true }
    private val lineStop = Paint().apply { color = Ui.BAD; strokeWidth = 3f; pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f) }
    private val lineTarget = Paint().apply { color = Ui.ACCENT; strokeWidth = 3f; pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f) }
    private val lineEntry = Paint().apply { color = Ui.MUTED; strokeWidth = 2f }
    private val label = Paint().apply { color = Ui.MUTED; textSize = 28f; isAntiAlias = true }

    fun set(b: List<List<Double>>, entry: Double, stop: Double, target: Double) {
        bands = b; this.entry = entry; this.stop = stop; this.target = target
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        setMeasuredDimension(width, (width * 0.6f).toInt())
    }

    override fun onDraw(c: Canvas) {
        if (bands.size < 2) return
        var lo = minOf(stop, bands.minOf { it[0] })
        var hi = maxOf(target, bands.maxOf { it[4] })
        val pad = (hi - lo) * 0.08
        lo -= pad; hi += pad
        val w = width.toFloat(); val h = height.toFloat()
        fun y(v: Double) = (h - (v - lo) / (hi - lo) * h).toFloat()
        fun x(i: Int) = i.toFloat() / (bands.size - 1) * w

        fun band(a: Int, b: Int, p: Paint) {
            val path = Path()
            for (i in bands.indices) { if (i == 0) path.moveTo(x(i), y(bands[i][b])) else path.lineTo(x(i), y(bands[i][b])) }
            for (i in bands.indices.reversed()) path.lineTo(x(i), y(bands[i][a]))
            path.close()
            c.drawPath(path, p)
        }
        band(0, 4, fillOuter)
        band(1, 3, fillInner)
        c.drawLine(0f, y(entry), w, y(entry), lineEntry)
        c.drawLine(0f, y(stop), w, y(stop), lineStop)
        c.drawLine(0f, y(target), w, y(target), lineTarget)
        val m = Path()
        for (i in bands.indices) { if (i == 0) m.moveTo(x(i), y(bands[i][2])) else m.lineTo(x(i), y(bands[i][2])) }
        c.drawPath(m, median)
        c.drawText("target %.2f".format(target), 8f, y(target) - 8f, label)
        c.drawText("stop %.2f".format(stop), 8f, y(stop) - 8f, label)
    }
}

/** Istogramma del prezzo di chiusura simulato, con entrata, stop e target. */
class HistChartView(ctx: Context) : View(ctx) {
    private var bins: List<Int> = emptyList()
    private var lo = 0.0
    private var hi = 0.0
    private var entry = 0.0
    private var stop = 0.0
    private var target = 0.0
    private val bar = Paint().apply { color = Color.parseColor("#7A8CA5"); style = Paint.Style.FILL }
    private val ls = Paint().apply { color = Ui.BAD; strokeWidth = 3f }
    private val lt = Paint().apply { color = Ui.ACCENT; strokeWidth = 3f }
    private val le = Paint().apply { color = Color.WHITE; strokeWidth = 3f }

    fun set(bins: List<Int>, lo: Double, hi: Double, entry: Double, stop: Double, target: Double) {
        this.bins = bins; this.lo = lo; this.hi = hi; this.entry = entry; this.stop = stop; this.target = target
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val width = MeasureSpec.getSize(w)
        setMeasuredDimension(width, (width * 0.35f).toInt())
    }

    override fun onDraw(c: Canvas) {
        if (bins.isEmpty() || hi <= lo) return
        val w = width.toFloat(); val h = height.toFloat()
        val mx = (bins.maxOrNull() ?: 1).coerceAtLeast(1)
        val bw = w / bins.size
        for ((i, v) in bins.withIndex()) {
            val bh = v.toFloat() / mx * h
            c.drawRect(i * bw + 1f, h - bh, (i + 1) * bw - 1f, h, bar)
        }
        fun x(v: Double) = ((v - lo) / (hi - lo) * w).toFloat()
        if (stop in lo..hi) c.drawLine(x(stop), 0f, x(stop), h, ls)
        if (target in lo..hi) c.drawLine(x(target), 0f, x(target), h, lt)
        if (entry in lo..hi) c.drawLine(x(entry), 0f, x(entry), h, le)
    }
}
