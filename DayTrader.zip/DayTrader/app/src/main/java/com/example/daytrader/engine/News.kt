package com.example.daytrader.engine

import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter

data class NewsItem(
    val id: String, val source: String, val kind: String, val ticker: String, val title: String, val summary: String,
    val link: String, val time: Long?, val form: String = "", val items: List<String> = emptyList(),
    val important: Boolean = false, var touches: List<String> = emptyList(), var tags: List<String> = emptyList()
)

data class Move(val ticker: String, val price: Double, val prevClose: Double, val pct: Double, val time: Long?)

/** Notizie e comunicati SEC dei tuoi titoli (porting di trader-news). */
object News {
    const val MOVE_PCT = 3.0

    val ITEMS_8K = mapOf(
        "1.01" to "accordo rilevante", "1.02" to "accordo terminato", "1.03" to "bancarotta",
        "1.05" to "incidente informatico", "2.01" to "acquisto o vendita di attività",
        "2.02" to "risultati trimestrali", "2.03" to "nuovo debito", "2.04" to "debito anticipato",
        "2.05" to "costi di ristrutturazione", "2.06" to "svalutazione", "3.01" to "avviso di delisting",
        "3.02" to "vendita di azioni non registrate", "3.03" to "modifica dei diritti degli azionisti",
        "4.01" to "cambio di revisore", "4.02" to "bilanci passati non più affidabili",
        "5.01" to "cambio di controllo", "5.02" to "cambio di dirigenti o consiglieri",
        "5.03" to "modifica statuto o anno fiscale", "5.07" to "esito del voto degli azionisti",
        "7.01" to "comunicazione Reg FD", "8.01" to "altri eventi", "9.01" to "allegati"
    )
    val IMPORTANT_ITEMS = setOf("1.03", "1.05", "2.02", "2.04", "2.06", "3.01", "4.02", "5.01", "5.02")

    private val KEYWORDS = listOf(
        "risultati" to Regex("\\bearnings\\b|\\bresults\\b|\\bEPS\\b|\\bguidance\\b|\\bforecast\\b", RegexOption.IGNORE_CASE),
        "analisti" to Regex("\\bupgrade[sd]?\\b|\\bdowngrade[sd]?\\b|price target|\\boutperform\\b|\\bunderperform\\b", RegexOption.IGNORE_CASE),
        "legale" to Regex("\\blawsuit\\b|\\bsued\\b|\\bprobe\\b|\\binvestigation\\b|\\bSEC charges\\b|\\bantitrust\\b|\\bjudge\\b|\\bcourt\\b", RegexOption.IGNORE_CASE),
        "operazioni" to Regex("\\bacqui(?:re|res|red|sition)\\b|\\bmerger\\b|\\bbuyout\\b|\\btakeover\\b|\\bdeal\\b", RegexOption.IGNORE_CASE),
        "capitale" to Regex("\\bdividend\\b|\\bbuyback\\b|\\brepurchase\\b|\\bstock split\\b|\\boffering\\b", RegexOption.IGNORE_CASE),
        "persone" to Regex("\\bCEO\\b|\\bCFO\\b|\\bresign|\\bsteps down\\b|\\bappoint", RegexOption.IGNORE_CASE),
        "rischio" to Regex("\\brecall\\b|\\bbankrupt|\\bdefault\\b|\\bdelist|\\bhack|\\bbreach\\b|\\boutage\\b", RegexOption.IGNORE_CASE),
        "sospensione" to Regex("\\bhalt(?:s|ed)?\\b|\\btrading (?:pause|suspen)", RegexOption.IGNORE_CASE),
        "autorità" to Regex("\\bFDA\\b|\\bapproval\\b|\\bapproves\\b|\\bclinical\\b|\\bFTC\\b|\\bDOJ\\b", RegexOption.IGNORE_CASE),
        "macro" to Regex("\\bFed\\b|\\bFOMC\\b|\\bCPI\\b|\\binflation\\b|\\bjobs report\\b|\\bpayrolls\\b|\\btariffs?\\b|\\bfutures\\b", RegexOption.IGNORE_CASE)
    )

    fun yahooUrl(t: String) = "https://feeds.finance.yahoo.com/rss/2.0/headline?s=${Market.yahooSymbol(t)}&region=US&lang=en-US"
    fun secFeedUrl(cik: String, form: String, count: Int = 10) =
        "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=$cik&type=$form&dateb=&owner=include&count=$count&output=atom"
    const val TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"

    fun parseTime(value: String): Long? {
        val v = value.trim()
        if (v.isEmpty()) return null
        return try { OffsetDateTime.parse(v, DateTimeFormatter.RFC_1123_DATE_TIME).toEpochSecond() } catch (e: Exception) {
            try { OffsetDateTime.parse(v.replace("Z", "+00:00")).toEpochSecond() } catch (e2: Exception) { null }
        }
    }

    fun parseRss(xml: String, ticker: String): List<NewsItem> {
        if (!xml.contains("<rss") && !xml.contains("<item")) throw EngineError("Il feed di $ticker non è un RSS valido")
        return Xml.blocks(xml, "item").map { it0 ->
            val link = Xml.text(it0, "link")
            val guid = Xml.text(it0, "guid").ifEmpty { link }
            NewsItem("rss:$guid", "Yahoo Finance", "headline", ticker, Xml.text(it0, "title"), Xml.text(it0, "description"), link, parseTime(Xml.text(it0, "pubDate")))
        }
    }

    fun parseSecAtom(xml: String, ticker: String): List<NewsItem> {
        if (!xml.contains("<feed")) throw EngineError("Il feed SEC di $ticker non è valido")
        val company = Xml.text(xml, "conformed-name")
        return Xml.blocks(xml, "entry").map { e ->
            val form = Xml.text(e, "filing-type")
            val acc = Xml.text(e, "accession-number")
            val items = Regex("\\d+\\.\\d+").findAll(Xml.text(e, "items-desc")).map { it.value }.toList()
            val labels = items.filter { it != "9.01" }.map { ITEMS_8K[it] ?: "punto $it" }
            val link = Xml.attr(e, "link", "href")
            var title = "${company.ifEmpty { ticker }} ha depositato un $form"
            if (labels.isNotEmpty()) title += ": " + labels.joinToString(", ")
            NewsItem("sec:$acc", "SEC EDGAR", "filing", ticker, title, Xml.text(e, "form-name"), link, parseTime(Xml.text(e, "updated")), form, items, items.toSet().intersect(IMPORTANT_ITEMS).isNotEmpty())
        }
    }

    fun parseMove(json: String, ticker: String): Move {
        val res = Market.chartResult(json, ticker)
        val meta = res["meta"] as? Map<*, *> ?: throw EngineError("Grafico di $ticker non utilizzabile")
        val price = meta["regularMarketPrice"] as? Double
        val prev = (meta["chartPreviousClose"] as? Double) ?: (meta["previousClose"] as? Double)
        if (price == null || prev == null || price == 0.0 || prev == 0.0) throw EngineError("Grafico di $ticker non utilizzabile")
        return Move(ticker, price, prev, Num.pyRound(100.0 * (price - prev) / prev, 2), (meta["regularMarketTime"] as? Double)?.toLong())
    }

    fun tag(items: List<NewsItem>, watch: Map<String, String>): List<NewsItem> {
        val pats = watch.mapValues { (t, name) ->
            val alts = arrayListOf("\\(${Regex.escape(t)}\\)", "\\$${Regex.escape(t)}\\b", "\\b(?:NYSE|NASDAQ|Nasdaq)\\s*:\\s*${Regex.escape(t)}\\b")
            if (name.length >= 4) alts.add("\\b" + Regex.escape(name).replace("\\ ", "[\\s-]") + "\\b")
            Regex(alts.joinToString("|"))
        }
        for (it0 in items) {
            val hay = "${it0.title} ${it0.summary}"
            val touches = LinkedHashSet<String>()
            if (it0.ticker in watch) touches.add(it0.ticker)
            for ((t, rx) in pats) if (rx.containsMatchIn(hay)) touches.add(t)
            it0.touches = touches.sorted()
            val tags = KEYWORDS.filter { (_, rx) -> rx.containsMatchIn(hay) }.map { it.first }.toMutableList()
            if (it0.kind == "filing" && "2.02" in it0.items && "risultati" !in tags) tags.add(0, "risultati")
            it0.tags = tags
        }
        return items
    }

    fun dedupe(items: List<NewsItem>): List<NewsItem> {
        val seen = HashMap<String, NewsItem>()
        val out = ArrayList<NewsItem>()
        for (it0 in items) {
            val day = it0.time?.let { TimeUtil.utcOf(it).toLocalDate().toString() } ?: ""
            val keys = listOf(it0.id, it0.link, it0.title.lowercase().replace(Regex("\\W+"), " ").trim() + "|" + day)
            val hit = keys.firstOrNull { it.isNotEmpty() && it in seen }?.let { seen[it] }
            if (hit != null) {
                hit.touches = (hit.touches + it0.touches).distinct().sorted()
                continue
            }
            keys.filter { it.isNotEmpty() }.forEach { seen[it] = it0 }
            out.add(it0)
        }
        return out
    }

    fun select(items: List<NewsItem>, nowEpoch: Long, hours: Int = 48): List<NewsItem> {
        val cutoff = nowEpoch - hours * 3600L
        val ahead = nowEpoch + 600
        return items.filter { it.time == null || (it.time >= cutoff && it.time <= ahead) }
            .sortedByDescending { it.time ?: nowEpoch }
    }

    fun cikMap(json: String): Map<String, String> {
        val doc = Json.parse(json) as? Map<*, *> ?: throw EngineError("Elenco ticker SEC non valido")
        val out = LinkedHashMap<String, String>()
        for (v in doc.values) {
            val m = v as? Map<*, *> ?: continue
            val t = (m["ticker"] as? String)?.uppercase()?.replace("-", ".") ?: continue
            val cik = (m["cik_str"] as? Double)?.toLong()?.toString() ?: continue
            out.putIfAbsent(t, cik.padStart(10, '0'))
        }
        return out
    }
}
