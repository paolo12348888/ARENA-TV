package com.example.daytrader.ui

import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import com.example.daytrader.MainActivity
import com.example.daytrader.Yahoo
import com.example.daytrader.engine.Alerts
import com.example.daytrader.engine.Bar
import com.example.daytrader.engine.EngineError
import com.example.daytrader.engine.Entry
import com.example.daytrader.engine.EntryResult
import com.example.daytrader.engine.EntryStatus
import com.example.daytrader.engine.ExitPlan
import com.example.daytrader.engine.Lean
import com.example.daytrader.engine.LedgerEntry
import com.example.daytrader.engine.Market
import com.example.daytrader.engine.Planner
import com.example.daytrader.engine.Risk
import com.example.daytrader.engine.Sizing
import com.example.daytrader.engine.TimeMachine
import com.example.daytrader.engine.TimeUtil
import com.example.daytrader.engine.TmPlan
import com.example.daytrader.engine.TmResult
import com.example.daytrader.engine.SizeResult
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

/** Ingresso, uscita, dimensione, rischio e Time Machine di UN'operazione (con replay di un giorno passato). */
class TradeScreen(act: MainActivity) : Screen(act) {
    private lateinit var symbol: EditText
    private lateinit var orMin: EditText
    private lateinit var stopKind: Spinner
    private lateinit var stopParam: EditText
    private lateinit var targetKind: Spinner
    private lateinit var targetParam: EditText
    private lateinit var day: EditText
    private lateinit var time: EditText
    private lateinit var manual: EditText
    private lateinit var out: LinearLayout
    private lateinit var status: TextView
    private var busy = false

    private val stopKeys = listOf("or_mid", "or_low", "pct", "atr", "price")
    private val stopNames = listOf("Metà dell'opening range", "Minimo dell'opening range", "% sotto l'ingresso", "ATR sotto l'ingresso", "Prezzo fisso")
    private val targetKeys = listOf("r", "price")
    private val targetNames = listOf("Multiplo del rischio (R)", "Prezzo fisso")

    override fun build(): View {
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Operazione"))
        col.addView(Ui.muted(ctx, "Entrata, uscita, quante azioni e le probabilità, per un titolo USA. Ora e giorno sono quelli di New York: per studiare una giornata passata scegli giorno e orario (replay)."))
        val (d0, t0) = defaultSession()
        symbol = Ui.input(ctx, "Titolo (es. TSLA)", "TSLA").also { it.inputType = it.inputType or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS }
        orMin = Ui.input(ctx, "Minuti dell'opening range", "15", number = true, decimal = false)
        stopKind = spinner(stopNames)
        stopParam = Ui.input(ctx, "Valore stop (solo per %, ATR o prezzo)", "", number = true)
        targetKind = spinner(targetNames)
        targetParam = Ui.input(ctx, "Valore target (R, es. 2, oppure prezzo)", "1", number = true)
        day = Ui.input(ctx, "Giorno AAAA-MM-GG", d0)
        time = Ui.input(ctx, "Orario HH:MM (New York)", t0)
        manual = Ui.input(ctx, "Prezzo d'ingresso manuale (facoltativo)", "", number = true)
        col.addView(Ui.section(ctx, "Titolo"))
        col.addView(symbol)
        col.addView(Ui.section(ctx, "Opening range"))
        col.addView(orMin)
        col.addView(Ui.section(ctx, "Stop"))
        col.addView(stopKind); col.addView(stopParam)
        col.addView(Ui.section(ctx, "Target"))
        col.addView(targetKind); col.addView(targetParam)
        col.addView(Ui.section(ctx, "Quando"))
        col.addView(day); col.addView(time)
        col.addView(Ui.muted(ctx, "Se non indichi un ingresso manuale, vale la prima candela da 5 minuti che chiude sopra il massimo dell'opening range."))
        col.addView(manual)
        col.addView(Ui.button(ctx, "Calcola (include 10.000 repliche)") { run() })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        out = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(out)
        col.addView(Ui.spacer(ctx, 12))
        col.addView(Ui.muted(ctx, Ui.DISCLAIMER))
        return scrolling(col)
    }

    fun preset(sym: String, d: String?) {
        view()
        symbol.setText(sym)
        if (d != null) {
            day.setText(d)
            val (_, t) = defaultSession()
            val m = TimeUtil.parseClock(t) ?: (15 * 60 + 30)
            time.setText(TimeUtil.clock24(minOf(m, 15 * 60 + 30)))
        }
        out.removeAllViews()
        status.text = ""
    }

    private class Input(
        val sym: String, val orMinutes: Int, val stopRule: String, val stopParam: Double?, val targetRule: String,
        val targetParam: Double, val day: String, val nowMin: Int, val manual: Double?
    )

    private fun readInput(): Input {
        val sym = symbol.text.toString().trim().uppercase()
        if (sym.isEmpty()) throw EngineError("Scrivi un titolo, per esempio TSLA.")
        val or = orMin.text.toString().trim().toIntOrNull() ?: throw EngineError("Opening range non valido (es. 15).")
        if (or < 5 || or % 5 != 0 || or > 120) throw EngineError("L'opening range deve essere un multiplo di 5 minuti tra 5 e 120.")
        val d = day.text.toString().trim()
        try { LocalDate.parse(d) } catch (e: Exception) { throw EngineError("Giorno non valido: usa AAAA-MM-GG, per esempio 2026-10-19.") }
        val m = TimeUtil.parseClock(time.text.toString()) ?: throw EngineError("Orario non valido: usa HH:MM, per esempio 10:15.")
        val sk = stopKeys[stopKind.selectedItemPosition]
        val sp = num(stopParam.text.toString())
        if ((sk == "pct" || sk == "atr" || sk == "price") && sp == null) throw EngineError("Per questo stop serve un valore numerico.")
        val tk = targetKeys[targetKind.selectedItemPosition]
        val tp = num(targetParam.text.toString()) ?: throw EngineError("Serve il valore del target (es. 1 o 2 per il multiplo del rischio).")
        val man = manual.text.toString().trim().let { if (it.isEmpty()) null else (num(it) ?: throw EngineError("Prezzo d'ingresso non valido.")) }
        return Input(sym, or, sk, sp, tk, tp, d, m, man)
    }

    private fun run() {
        if (busy) return
        val inp = try { readInput() } catch (e: EngineError) { status.text = e.message; status.setTextColor(Ui.BAD); return }
        busy = true
        out.removeAllViews()
        status.setTextColor(Ui.MUTED)
        status.text = "Scarico le candele di ${inp.sym} da Yahoo…"
        act.bg {
            try {
                val text = Yahoo.chart(inp.sym, "60d", "5m")
                val res = Market.chartResult(text, inp.sym)
                val dayDate = LocalDate.parse(inp.day)
                val at = LocalDateTime.of(dayDate, LocalTime.of(inp.nowMin / 60, inp.nowMin % 60))
                val data = Market.parseBars(res, TimeUtil.epochOf(at))
                val bars = data.bars
                act.ui { status.text = "Calcolo e simulo (10.000 repliche)…" }
                val closed = TimeUtil.closedReason(dayDate)
                val entry = Entry.check(inp.sym, inp.day, bars, "orb", null, inp.orMinutes, null, inp.nowMin, closed)
                val ctxData = compute(inp, bars, entry, at)
                act.ui { busy = false; status.text = ""; render(inp, entry, ctxData) }
            } catch (e: Exception) {
                act.ui { busy = false; status.setTextColor(Ui.BAD); status.text = e.message ?: e.javaClass.simpleName }
            }
        }
    }

    private class Computed(val plan: ExitPlan?, val size: SizeResult?, val risk: com.example.daytrader.engine.RiskVerdict?, val tm: TmResult?, val note: String?)

    private fun compute(inp: Input, bars: List<Bar>, entry: EntryResult, at: LocalDateTime): Computed {
        val cfg = act.store.config()
        val dayBars = bars.filter { it.date == inp.day }.sortedBy { it.slot }
        val entryPrice: Double
        val entryBar: Int
        val entryTime: String
        if (inp.manual != null) {
            if (dayBars.isEmpty()) throw EngineError("Nessuna candela completa per ${inp.day} a quell'ora.")
            entryPrice = inp.manual
            entryBar = dayBars.last().slot
            entryTime = TimeUtil.clock12(TimeUtil.OPEN_MIN + 5 * (entryBar + 1))
        } else if (entry.status == EntryStatus.TRIGGERED && entry.triggerPrice != null && entry.triggerBar != null) {
            entryPrice = entry.triggerPrice
            entryBar = entry.triggerBar
            entryTime = entry.triggerTime ?: ""
        } else {
            return Computed(null, null, null, null, null)
        }
        val atr = if (inp.stopRule == "atr") {
            val upto = dayBars.filter { it.slot <= entryBar }
            if (upto.isEmpty()) null else Planner.atrOf(upto)
        } else null
        val plan = Planner.compute(
            inp.sym, entryPrice, inp.stopRule, inp.stopParam, inp.targetRule, inp.targetParam,
            entry.orHigh, entry.orLow, atr, inp.orMinutes, cfg.flatBy, inp.day, entryBar, entryTime, "orb"
        )
        val size = Sizing.sizeTrade(inp.sym, plan.entry, plan.stop, plan.target, cfg)
        val today = act.store.ledger().filter { it.date == inp.day }
        val risk = Risk.check(size, cfg, at, today)
        val tm = TimeMachine.run(TmPlan(inp.sym, inp.day, plan.entry, plan.stop, plan.target, entryBar, plan.stopRule, inp.orMinutes), bars)
        return Computed(plan, size, risk, tm, null)
    }

    private fun leanText(l: Lean): Pair<String, Int> = when (l) {
        Lean.COIN_FLIP -> "Quasi un testa o croce" to Ui.WARN
        Lean.BREAK_EVEN -> "In pareggio: né vantaggio né svantaggio" to Ui.WARN
        Lean.LEANS_TARGET -> "Pende verso il target" to Ui.ACCENT
        Lean.LEANS_STOP -> "Pende verso lo stop" to Ui.BAD
        Lean.STRONG_TARGET -> "Netto vantaggio verso il target" to Ui.ACCENT
        Lean.STRONG_STOP -> "Netto vantaggio verso lo stop" to Ui.BAD
        Lean.NONE -> "Nessuna lettura possibile" to Ui.MUTED
    }

    private fun render(inp: Input, entry: EntryResult, c: Computed) {
        out.removeAllViews()
        out.addView(Ui.section(ctx, "Entrata"))
        val ec = Ui.card(ctx)
        val col = when (entry.status) {
            EntryStatus.TRIGGERED -> Ui.ACCENT
            EntryStatus.WAITING, EntryStatus.FORMING -> Ui.WARN
            else -> Ui.BAD
        }
        ec.addView(Ui.text(ctx, entry.message, 14f, col, true))
        if (entry.orHigh != null && entry.orLow != null) {
            ec.addView(Ui.row(ctx, "Range di apertura", "${Ui.p2(entry.orLow)} - ${Ui.p2(entry.orHigh)}"))
        }
        out.addView(ec)
        val plan = c.plan
        val size = c.size
        val tm = c.tm
        val risk = c.risk
        if (plan == null || size == null || tm == null || risk == null) {
            out.addView(Ui.muted(ctx, "Nessun ingresso: scrivi un prezzo d'ingresso manuale se vuoi simulare comunque.", 13f))
            return
        }
        out.addView(Ui.section(ctx, "Piano di uscita"))
        val pc = Ui.card(ctx)
        pc.addView(Ui.row(ctx, "Ingresso (${plan.entryTime})", Ui.p2(plan.entry)))
        pc.addView(Ui.row(ctx, "Stop: ${plan.stopLabel}", Ui.p2(plan.stop), Ui.BAD))
        pc.addView(Ui.row(ctx, "Target: ${plan.targetLabel}", Ui.p2(plan.target), Ui.ACCENT))
        pc.addView(Ui.row(ctx, "Rischio per azione", Ui.p2(plan.risk)))
        pc.addView(Ui.row(ctx, "Rendimento / rischio", Ui.p2(plan.rewardRisk)))
        pc.addView(Ui.row(ctx, "Esci comunque entro", plan.flatBy + " (NY)"))
        out.addView(pc)

        out.addView(Ui.section(ctx, "Quante azioni"))
        val sc = Ui.card(ctx)
        if (size.refusal != null) {
            sc.addView(Ui.text(ctx, size.refusal, 14f, Ui.BAD, true))
        } else {
            sc.addView(Ui.row(ctx, "Azioni", size.qty.toString()))
            sc.addView(Ui.row(ctx, "Costo", Ui.money(size.cost)))
            sc.addView(Ui.row(ctx, "Perdita massima allo stop", Ui.money(size.maxLoss), Ui.WARN))
            sc.addView(Ui.muted(ctx, "Limite che ha deciso: ${size.boundBy}"))
        }
        out.addView(sc)

        out.addView(Ui.section(ctx, "Controllo del rischio"))
        val rc = Ui.card(ctx)
        rc.addView(Ui.badge(ctx, if (risk.pass) "OK" else "BLOCCATA", if (risk.pass) Ui.ACCENT else Ui.BAD))
        for (b in risk.blocks) rc.addView(Ui.text(ctx, "• $b", 13f, Ui.BAD))
        for (w in risk.warnings) rc.addView(Ui.text(ctx, "• $w", 13f, Ui.WARN))
        for (n in risk.notes) rc.addView(Ui.muted(ctx, "• $n", 13f))
        out.addView(rc)

        out.addView(Ui.section(ctx, "Time Machine"))
        val tc = Ui.card(ctx)
        val (lt, lc) = leanText(tm.lean)
        tc.addView(Ui.text(ctx, lt, 16f, lc, true))
        val mc = tm.mc
        tc.addView(Ui.row(ctx, "Target per primo", Ui.pctText(mc.pTarget), Ui.ACCENT))
        tc.addView(Ui.row(ctx, "Stop per primo", Ui.pctText(mc.pStop), Ui.BAD))
        tc.addView(Ui.row(ctx, "Né l'uno né l'altro", Ui.pctText(mc.pNeither)))
        tc.addView(Ui.row(ctx, "Chiude in verde", Ui.pctText(mc.pGreen)))
        tc.addView(Ui.row(ctx, "Quota target tra i due", Ui.pctText(tm.share)))
        tc.addView(Ui.row(ctx, "Soglia di pareggio", Ui.pctText(tm.breakEven)))
        tc.addView(Ui.row(ctx, "Chiusura mediana", Ui.p2(mc.medianClose)))
        tc.addView(Ui.row(ctx, "R medio", Ui.p2(mc.avgR)))
        tc.addView(Ui.muted(ctx, "${mc.replays} repliche, seme ${mc.seed}, ${tm.poolSessions} sessioni reali dal ${tm.poolFrom} al ${tm.poolTo}."))
        for (w in tm.warnings) tc.addView(Ui.text(ctx, "• $w", 13f, Ui.WARN))
        if (mc.pNeither >= TimeMachine.MANY_NEITHER) tc.addView(Ui.text(ctx, "• Spesso non succede nulla prima della chiusura: il risultato dipende dall'uscita forzata.", 13f, Ui.WARN))
        out.addView(tc)

        out.addView(Ui.muted(ctx, "Ventaglio dei prezzi simulati"))
        out.addView(FanChartView(ctx).also { it.set(mc.bands, plan.entry, plan.stop, plan.target) })
        out.addView(Ui.muted(ctx, "Chiusura a fine sessione (istogramma)"))
        out.addView(HistChartView(ctx).also { it.set(mc.histBins, mc.histLo, mc.histHi, plan.entry, plan.stop, plan.target) })

        val h = tm.history
        out.addView(Ui.section(ctx, "Storico reale della stessa regola"))
        val hc = Ui.card(ctx)
        hc.addView(Ui.row(ctx, "Sessioni esaminate", h.sessions.toString()))
        hc.addView(Ui.row(ctx, "Volte che è scattata", h.triggered.toString()))
        hc.addView(Ui.row(ctx, "Target", h.target.toString(), Ui.ACCENT))
        hc.addView(Ui.row(ctx, "Stop", h.stop.toString(), Ui.BAD))
        hc.addView(Ui.row(ctx, "Né l'uno né l'altro", h.close.toString()))
        h.avgR?.let { hc.addView(Ui.row(ctx, "R medio", Ui.p2(it))) }
        out.addView(hc)
        out.addView(Ui.muted(ctx, "È una simulazione costruita sulle ultime sessioni del titolo, non una previsione: notizie, trimestrali o sospensioni non sono incluse."))

        out.addView(Ui.section(ctx, "Azioni"))
        out.addView(Ui.button(ctx, "Crea avvisi (stop, target, uscita)") {
            val rules = act.store.rules()
            val ids = rules.map { it.id }.toSet()
            val fresh = Alerts.fromPlan(plan, inp.day).filter { it.id !in ids }
            act.store.saveRules(rules + fresh)
            status.setTextColor(Ui.ACCENT)
            status.text = "Avvisi creati: ${fresh.size}. Attiva il controllo nella scheda Avvisi."
        })
        if (size.refusal == null && size.qty > 0) {
            out.addView(Ui.button(ctx, "Segna come eseguita (conta nei limiti giornalieri)", Ui.WARN) {
                act.store.addLedger(LedgerEntry(inp.day, inp.sym, size.maxLoss, true))
                status.setTextColor(Ui.ACCENT)
                status.text = "Registrata: ${inp.sym}, perdita massima ${Ui.money(size.maxLoss)}. L'app non invia ordini: l'ordine lo metti tu dal tuo broker."
            })
        }
    }
}
