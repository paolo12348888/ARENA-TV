package com.example.daytrader.ui

import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.example.daytrader.Http
import com.example.daytrader.MainActivity
import com.example.daytrader.engine.Pelosi
import com.example.daytrader.engine.TimeUtil

/** Dichiarazioni di operazioni dei membri della Camera USA (indice ufficiale). Il PDF si apre dal link. */
class PelosiScreen(act: MainActivity) : Screen(act) {
    private lateinit var member: EditText
    private lateinit var status: TextView
    private lateinit var out: LinearLayout
    @Volatile private var running = false

    override fun build(): View {
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Camera USA"))
        col.addView(Ui.muted(ctx, "Elenco ufficiale delle dichiarazioni di operazioni in titoli dei deputati (Clerk della Camera). Sono dati pubblici e arrivano fino a 45 giorni dopo l'operazione: non sono informazioni riservate. Il contenuto si legge aprendo il PDF."))
        member = Ui.input(ctx, "Cognome o 'Cognome, Nome'", "Pelosi")
        col.addView(member)
        col.addView(Ui.button(ctx, "Cerca dichiarazioni") { go() })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        out = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(out)
        return scrolling(col)
    }

    private fun go() {
        if (running) return
        val m = member.text.toString()
        running = true
        out.removeAllViews()
        status.setTextColor(Ui.MUTED); status.text = "Scarico l'indice del Clerk…"
        act.bg {
            try {
                val year = TimeUtil.nowNy().year
                var rows = try {
                    Pelosi.parseIndex(Pelosi.readIndexBytes(Http.get(Pelosi.indexUrl(year), timeoutMs = 60000)), year)
                } catch (e: Exception) {
                    if (year > 2000) Pelosi.parseIndex(Pelosi.readIndexBytes(Http.get(Pelosi.indexUrl(year - 1), timeoutMs = 60000)), year - 1) else throw e
                }
                rows = rows.filter { Pelosi.memberMatch(it, m) }
                act.ui {
                    status.text = ""
                    out.addView(Ui.section(ctx, "Dichiarazioni: ${rows.size}"))
                    for (r in rows.take(60)) {
                        val c = Ui.card(ctx)
                        c.addView(Ui.text(ctx, r.name + (if (r.district.isNotEmpty()) " (${r.district})" else ""), 14f, Ui.TEXT, true))
                        c.addView(Ui.muted(ctx, "${r.typeName} · depositata ${r.filed ?: "n/d"}"))
                        c.addView(Ui.button(ctx, "Apri il PDF") {
                            try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.url))) } catch (e: Exception) { }
                        })
                        out.addView(c)
                    }
                    if (rows.isEmpty()) out.addView(Ui.muted(ctx, "Nessuna dichiarazione trovata."))
                }
            } catch (e: Exception) {
                act.ui { status.setTextColor(Ui.BAD); status.text = e.message ?: e.javaClass.simpleName }
            } finally { running = false }
        }
    }
}
