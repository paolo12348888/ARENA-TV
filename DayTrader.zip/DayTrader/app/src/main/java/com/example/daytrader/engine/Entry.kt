package com.example.daytrader.engine

enum class EntryStatus { CLOSED_MARKET, NOT_OPEN, FORMING, WAITING, TRIGGERED, EXPIRED, NO_DATA }

data class EntryResult(
    val status: EntryStatus,
    val symbol: String,
    val message: String,
    val orHigh: Double? = null, val orLow: Double? = null,
    val level: Double? = null,
    val lastClose: Double? = null,
    val triggerTime: String? = null, val triggerPrice: Double? = null,
    val triggerBar: Int? = null, val triggerStartTime: String? = null,
    val date: String = "",
    val orMinutes: Int = 15
)

/** Entry Timer: la prima candela COMPLETA che CHIUDE sopra il livello (porting di trader-entry). */
object Entry {
    fun check(
        symbol: String, date: String, bars: List<Bar>, setup: String = "orb", level: Double? = null,
        orMinutes: Int = 15, minVolX: Double? = null, nowMin: Int, marketClosedReason: String? = null,
        noBefore: Int = 9 * 60 + 45, noAfter: Int = 15 * 60 + 30
    ): EntryResult {
        val sym = symbol.uppercase()
        if (marketClosedReason != null) {
            return EntryResult(EntryStatus.CLOSED_MARKET, sym, "Mercato chiuso ($marketClosedReason).", date = date, orMinutes = orMinutes)
        }
        if (nowMin < TimeUtil.OPEN_MIN) return EntryResult(EntryStatus.NOT_OPEN, sym, "Il mercato non è ancora aperto (apre alle 9:30 ora di New York).", date = date, orMinutes = orMinutes)
        val n = orMinutes / 5
        if (setup == "orb" && nowMin < TimeUtil.OPEN_MIN + orMinutes) {
            return EntryResult(EntryStatus.FORMING, sym, "Il range di apertura si sta ancora formando.", date = date, orMinutes = orMinutes)
        }
        val day = bars.filter { it.date == date }.sortedBy { it.slot }
        val bySlot = day.associateBy { it.slot }
        var oh: Double? = null
        var ol: Double? = null
        val lvl: Double
        if (setup == "orb") {
            if ((0 until n).any { it !in bySlot }) {
                return EntryResult(EntryStatus.NO_DATA, sym, "Mancano candele del range di apertura (sospensione o titolo poco scambiato).", date = date, orMinutes = orMinutes)
            }
            oh = Num.pyRound2((0 until n).maxOf { bySlot[it]!!.h })
            ol = Num.pyRound2((0 until n).minOf { bySlot[it]!!.l })
            lvl = oh
        } else {
            lvl = level ?: throw EngineError("Per il setup a livello serve un prezzo.")
        }
        if (day.isEmpty()) return EntryResult(EntryStatus.NO_DATA, sym, "Nessuna candela completa per oggi.", oh, ol, lvl, date = date, orMinutes = orMinutes)
        val rangeVol = if (setup == "orb") (0 until n).map { bySlot[it]!!.v }.average() else 0.0
        val first = if (setup == "orb") n else 0
        for (b in day) {
            if (b.slot < first) continue
            if (b.c > lvl) {
                if (minVolX != null && setup == "orb" && rangeVol > 0 && b.v < minVolX * rangeVol) continue
                val closeMin = TimeUtil.OPEN_MIN + 5 * (b.slot + 1)
                return EntryResult(
                    EntryStatus.TRIGGERED, sym,
                    "ENTRATA alle ${TimeUtil.clock12(closeMin)} a ${"%.2f".format(b.c)}: la candela delle ${b.start} ha chiuso sopra il livello ${"%.2f".format(lvl)}.",
                    oh, ol, lvl, b.c, TimeUtil.clock12(closeMin), b.c, b.slot, b.start, date, orMinutes
                )
            }
        }
        val last = day.last()
        val dist = lvl - last.c
        return if (nowMin >= noAfter) {
            EntryResult(EntryStatus.EXPIRED, sym, "Setup scaduto: nessuna chiusura sopra il livello entro le ${TimeUtil.clock24(noAfter)}.", oh, ol, lvl, last.c, date = date, orMinutes = orMinutes)
        } else {
            EntryResult(
                EntryStatus.WAITING, sym,
                "IN ATTESA: ultima chiusura %.2f, a %.2f sotto il livello %.2f (%.2f%%).".format(last.c, dist, lvl, -100 * dist / lvl),
                oh, ol, lvl, last.c, date = date, orMinutes = orMinutes
            )
        }
    }
}
