package com.example.daytrader

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.example.daytrader.ui.AlertsScreen
import com.example.daytrader.ui.AnalystScreen
import com.example.daytrader.ui.NewsScreen
import com.example.daytrader.ui.PelosiScreen
import com.example.daytrader.ui.ScannerScreen
import com.example.daytrader.ui.Screen
import com.example.daytrader.ui.SettingsScreen
import com.example.daytrader.ui.TradeScreen
import com.example.daytrader.ui.Ui
import java.util.concurrent.Executors

class MainActivity : Activity() {
    lateinit var store: Store
    private val pool = Executors.newFixedThreadPool(4)
    private lateinit var content: FrameLayout
    private val tabs = ArrayList<Pair<String, Screen>>()
    private val buttons = ArrayList<Button>()
    lateinit var trade: TradeScreen

    /** Esegue un lavoro lento fuori dal thread principale. */
    fun bg(work: () -> Unit) { pool.execute { try { work() } catch (e: Throwable) { /* le schermate gestiscono i propri errori */ } } }

    /** Esegue sul thread principale, se la schermata esiste ancora. */
    fun ui(work: () -> Unit) { runOnUiThread { if (!isFinishing && !isDestroyed) work() } }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        trade = TradeScreen(this)
        tabs.add("Scansione" to ScannerScreen(this))
        tabs.add("Operazione" to trade)
        tabs.add("Notizie" to NewsScreen(this))
        tabs.add("Bilanci" to AnalystScreen(this))
        tabs.add("Camera" to PelosiScreen(this))
        tabs.add("Avvisi" to AlertsScreen(this))
        tabs.add("Impostazioni" to SettingsScreen(this))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Ui.CARD) }
        for ((i, t) in tabs.withIndex()) {
            val b = Button(this).apply {
                text = t.first
                isAllCaps = false
                textSize = 13f
                setTextColor(Ui.MUTED)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { select(i) }
            }
            buttons.add(b)
            bar.addView(b, LinearLayout.LayoutParams(-2, Ui.dp(this, 48)))
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Ui.CARD)
            addView(bar)
        }
        root.addView(scroller, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        select(0)

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    fun select(i: Int) {
        content.removeAllViews()
        val s = tabs[i].second
        content.addView(s.view(), FrameLayout.LayoutParams(-1, -1))
        s.onShown()
        for ((k, b) in buttons.withIndex()) b.setTextColor(if (k == i) Ui.ACCENT else Ui.MUTED)
    }

    /** Dalla scansione all'operazione: precompila titolo e giorno. */
    fun openTrade(symbol: String, day: String?) {
        trade.preset(symbol, day)
        select(1)
    }
}
