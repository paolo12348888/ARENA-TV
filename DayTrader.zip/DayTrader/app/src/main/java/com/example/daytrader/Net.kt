package com.example.daytrader

import com.example.daytrader.engine.EngineError
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Richieste HTTP semplici (da chiamare sempre fuori dal thread principale). */
object Http {
    private const val UA_WEB = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    fun get(url: String, userAgent: String = UA_WEB, timeoutMs: Int = 30000): ByteArray {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Accept", "*/*")
            val code = conn.responseCode
            if (code != 200) {
                val msg = when (code) {
                    404 -> "non trovato (404)"
                    429 -> "troppe richieste (429): riprova tra un minuto"
                    403 -> "accesso rifiutato (403)"
                    else -> "errore HTTP $code"
                }
                throw HttpError(code, "$msg: ${url.substringBefore('?').takeLast(60)}")
            }
            val out = ByteArrayOutputStream()
            conn.inputStream.use { it.copyTo(out) }
            return out.toByteArray()
        } catch (e: HttpError) {
            throw e
        } catch (e: Exception) {
            throw EngineError("Connessione non riuscita: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn?.disconnect()
        }
    }

    fun text(url: String, userAgent: String = UA_WEB): String = String(get(url, userAgent), Charsets.UTF_8)
}

class HttpError(val code: Int, message: String) : Exception(message)

/** Yahoo Finance: due host, un solo nuovo tentativo dopo un 429 o un errore del server. */
object Yahoo {
    private val HOSTS = listOf("https://query2.finance.yahoo.com", "https://query1.finance.yahoo.com")

    fun get(path: String): String {
        var last: Exception? = null
        for ((i, host) in HOSTS.withIndex()) {
            try {
                return Http.text(host + path)
            } catch (e: HttpError) {
                last = e
                if (e.code == 404) break
                if (e.code == 429 && i == 0) {
                    try { Thread.sleep(2000) } catch (ie: InterruptedException) { }
                }
            } catch (e: EngineError) {
                last = e
            }
        }
        throw last ?: EngineError("Yahoo non risponde")
    }

    fun chart(sym: String, range: String, interval: String): String =
        get("/v8/finance/chart/${com.example.daytrader.engine.Market.yahooSymbol(sym)}?range=$range&interval=$interval")

    fun spark(symbols: List<String>, range: String, interval: String): String =
        get("/v7/finance/spark?symbols=" + symbols.joinToString(",") { com.example.daytrader.engine.Market.yahooSymbol(it) } + "&range=$range&interval=$interval")
}
