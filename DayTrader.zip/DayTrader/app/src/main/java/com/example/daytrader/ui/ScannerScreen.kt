package com.example.daytrader.ui

import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import com.example.daytrader.Http
import com.example.daytrader.MainActivity
import com.example.daytrader.Yahoo
import com.example.daytrader.engine.EngineError
import com.example.daytrader.engine.Scanner
import com.example.daytrader.engine.Series
import com.example.daytrader.engine.TimeUtil
import java.time.LocalDate

/** Scansione: rotture dell'opening range (5 minuti) e setup giornalieri, sulla tua lista o su tutto il mercato. */
class ScannerScreen(act: MainActivity) : Screen(act) {
    private lateinit var mode: Spinner
    private lateinit var source: Spinner
    private lateinit var orMin: EditText
    private lateinit var day: EditText
    private lateinit var time: EditText
    private lateinit var minPrice: EditText
    private lateinit var minVol: EditText
    private lateinit var status: TextView
    private lateinit var out: LinearLayout
    @Volatile private var running = false
    @Volatile private var cancel = false

    companion object { private var universe: List<String>? = null }

    override fun build(): View {
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Scansione"))
        col.addView(Ui.muted(ctx, "Cerca titoli con una rottura dell'opening range o con setup sui prezzi giornalieri. Sul mercato intero ci vogliono alcuni minuti: tieni lo schermo acceso."))
        val (d0, t0) = defaultSession()
        mode = spinner(listOf("Rottura opening range (5 min)", "Setup giornalieri"))
        source = spinner(listOf("La mia lista", "Tutto il mercato USA (~5.900 titoli)"))
        orMin = Ui.input(ctx, "Opening range (minuti)", "15", number = true, decimal = false)
        day = Ui.input(ctx, "Giorno AAAA-MM-GG", d0)
        time = Ui.input(ctx, "Orario HH:MM (New York)", TimeUtil.clock24(minOf(TimeUtil.parseClock(t0) ?: 600, 15 * 60 + 30)))
        minPrice = Ui.input(ctx, "Prezzo minimo $", "5", number = true)
        minVol = Ui.input(ctx, "Volume minimo", "500000", number = true, decimal = false)
        for (v in listOf(mode, source)) col.addView(v)
        col.addView(Ui.section(ctx, "Solo per la rottura"))
        col.addView(orMin); col.addView(day); col.addView(time)
        col.addView(Ui.section(ctx, "Filtri di liquidità"))
        col.addView(minPrice); col.addView(minVol)
        col.addView(Ui.button(ctx, "Avvia scansione") { start() })
        col.addView(Ui.button(ctx, "Annulla", Ui.BAD) { cancel = true })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        out = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(out)
        col.addView(Ui.spacer(ctx, 12))
        col.addView(Ui.muted(ctx, Ui.DISCLAIMER))
        return scrolling(col)
    }

    private fun say(s: String, err: Boolean = false) = act.ui { status.setTextColor(if (err) Ui.BAD else Ui.MUTED); status.text = s }

    private fun start() {
        if (running) return
        val orb = mode.selectedItemPosition == 0
        val full = source.selectedItemPosition == 1
        val or = orMin.text.toString().trim().toIntOrNull() ?: 15
        val dayStr = day.text.toString().trim()
        val at = TimeUtil.parseClock(time.text.toString())
        val mp = num(minPrice.text.toString()) ?: 0.0
        val mv = num(minVol.text.toString()) ?: 0.0
        out.removeAllViews()
        running = true; cancel = false
        act.bg {
            try {
                val symbols = if (full) loadUniverse() else act.store.watchlist
                if (symbols.isEmpty()) throw EngineError("La lista è vuota: aggiungi titoli in Impostazioni.")
                if (orb) scanOrb(symbols, or, dayStr, at, mp, mv) else scanDaily(symbols, mp, mv.toLong())
            } catch (e: Exception) {
                say(e.message ?: e.javaClass.simpleName, true)
            } finally { running = false }
        }
    }

    private fun loadUniverse(): List<String> {
        universe?.let { return it }
        say("Scarico l'elenco dei titoli da Nasdaq Trader…")
        val a = Http.text("https://www.nasdaqtrader.com/dynamic/symdir/nasdaqlisted.txt")
        val b = Http.text("https://www.nasdaqtrader.com/dynamic/symdir/otherlisted.txt")
        val u = Scanner.buildUniverse(listOf(a, b)).kept.map { it.first }
        universe = u
        return u
    }

    private fun fetchBatches(symbols: List<String>, range: String, interval: String): Map<String, Series> {
        val all = LinkedHashMap<String, Series>()
        val batches = symbols.chunked(20)
        for ((i, b) in batches.withIndex()) {
            if (cancel) throw EngineError("Scansione annullata.")
            say("Scarico i prezzi: ${i + 1} / ${batches.size}…")
            try { all.putAll(Scanner.parseSpark(Yahoo.spark(b, range, interval))) } catch (e: EngineError) { /* lotto saltato */ }
            try { Thread.sleep(300) } catch (e: InterruptedException) { }
        }
        return all
    }

    private fun scanOrb(symbols: List<String>, or: Int, dayStr: String, at: Int?, mp: Double, mv: Double) {
        val d = try { LocalDate.parse(dayStr) } catch (e: Exception) { throw EngineError("Giorno non valido: usa AAAA-MM-GG.") }
        if (at == null) throw EngineError("Orario non valido: usa HH:MM.")
        val (dd, cutoff) = Scanner.orbWindow(TimeUtil.nowNy(), at, or, 15 * 60 + 30, d)
        val recent = java.time.temporal.ChronoUnit.DAYS.between(dd, TimeUtil.nowNy().toLocalDate()) <= 3
        val stage1 = fetchBatches(symbols, if (recent) "5d" else "1mo", "5m")
        var n = 0
        val (hits, counts, failed) = Scanner.scanOrb(stage1, symbols, dd, cutoff, or, mp, mv, { sym ->
            if (cancel) throw EngineError("annullata")
            n++
            say("Confermo i candidati con il grafico completo: $n…")
            try { Thread.sleep(250) } catch (e: InterruptedException) { }
            Scanner.parseChartSeries(Yahoo.chart(sym, if (recent) "5d" else "1mo", "5m"), sym)
        }, 200)
        act.ui {
            status.text = ""
            out.removeAllViews()
            out.addView(Ui.section(ctx, "Rotture trovate: ${hits.size}"))
            out.addView(Ui.muted(ctx, "Titoli letti ${counts.fetched} su ${counts.requested}, esaminati ${counts.scanned}. " +
                counts.extra.entries.filter { it.value > 0 }.joinToString(", ") { "${it.key}: ${it.value}" }))
            if (failed.isNotEmpty()) out.addView(Ui.muted(ctx, "Non confermati per errore: ${failed.size}"))
            for (h in hits.take(100)) {
                val c = Ui.card(ctx)
                c.addView(Ui.row(ctx, h.symbol, "%.2f $".format(h.price), Ui.ACCENT))
                c.addView(Ui.muted(ctx, "Range ${Ui.p2(h.orLow)} - ${Ui.p2(h.orHigh)} · sopra di %.2f%% · chiusa alle ${h.at}".format(h.pctOver)))
                c.addView(Ui.button(ctx, "Apri operazione") { act.openTrade(h.symbol, dd.toString()) })
                out.addView(c)
            }
            if (hits.isEmpty()) out.addView(Ui.muted(ctx, "Nessuna rottura a quell'ora con questi filtri."))
        }
    }

    private fun scanDaily(symbols: List<String>, mp: Double, mv: Long) {
        val data = fetchBatches(symbols, "6mo", "1d")
        val (hits, counts) = Scanner.scanDaily(data, symbols, TimeUtil.nowNy(), mp, mv)
        act.ui {
            status.text = ""
            out.removeAllViews()
            out.addView(Ui.section(ctx, "Setup trovati: ${hits.size}"))
            out.addView(Ui.muted(ctx, "Titoli letti ${counts.fetched} su ${counts.requested}, esaminati ${counts.scanned}."))
            for (h in hits.take(150)) {
                val c = Ui.card(ctx)
                c.addView(Ui.row(ctx, h.symbol, "%.2f $".format(h.price), Ui.ACCENT))
                c.addView(Ui.muted(ctx, h.setups.joinToString(", ") { Scanner.SETUP_LABELS[it] ?: it } + " · RSI %.0f · chiusura del ${h.closeDate}".format(h.rsi)))
                c.addView(Ui.button(ctx, "Apri operazione") { act.openTrade(h.symbol, null) })
                out.addView(c)
            }
            if (hits.isEmpty()) out.addView(Ui.muted(ctx, "Nessun setup con questi filtri."))
        }
    }
}
