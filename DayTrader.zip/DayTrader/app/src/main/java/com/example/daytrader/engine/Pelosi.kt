package com.example.daytrader.engine

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

data class Filing(
    val docId: String, val type: String, val typeName: String, val last: String, val first: String,
    val name: String, val district: String, val year: Int, val filed: String?, val url: String
)

/** Dichiarazioni dei membri della Camera USA (indice ufficiale del Clerk). Il contenuto dei PDF si apre dal link. */
object Pelosi {
    val FILING_TYPES = mapOf(
        "P" to "Operazioni in titoli (PTR)", "O" to "Relazione annuale", "A" to "Modifica", "C" to "Relazione del candidato",
        "X" to "Proroga", "T" to "Cessazione", "W" to "Esenzione", "D" to "Nuovo membro o candidato", "H" to "Nuovo dichiarante"
    )
    fun indexUrl(year: Int) = "https://disclosures-clerk.house.gov/public_disc/financial-pdfs/${year}FD.zip"
    private fun ptrUrl(y: Int, doc: String) = "https://disclosures-clerk.house.gov/public_disc/ptr-pdfs/$y/$doc.pdf"
    private fun fdUrl(y: Int, doc: String) = "https://disclosures-clerk.house.gov/public_disc/financial-pdfs/$y/$doc.pdf"

    fun readIndexBytes(data: ByteArray): String {
        if (data.size > 2 && data[0] == 'P'.code.toByte() && data[1] == 'K'.code.toByte()) {
            ZipInputStream(ByteArrayInputStream(data)).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (e.name.lowercase().endsWith(".xml")) return String(z.readBytes(), Charsets.UTF_8).removePrefix("\uFEFF")
                }
            }
            throw EngineError("Nessun file XML nello ZIP dell'indice.")
        }
        return String(data, Charsets.UTF_8).removePrefix("\uFEFF")
    }

    fun iso(mdy: String): String? {
        val m = Regex("^\\s*(\\d{1,2})/(\\d{1,2})/(\\d{2,4})\\s*$").matchEntire(mdy) ?: return null
        var y = m.groupValues[3].toInt()
        if (y < 100) y += 2000
        return "%04d-%02d-%02d".format(y, m.groupValues[1].toInt(), m.groupValues[2].toInt())
    }

    fun parseIndex(xml: String, year: Int): List<Filing> {
        if (!xml.contains("<Member")) throw EngineError("L'indice non è un XML valido.")
        val out = ArrayList<Filing>()
        for (b in Xml.blocks(xml, "Member")) {
            fun f(t: String) = Xml.text(b, t)
            val doc = f("DocID"); val kind = f("FilingType")
            val y = f("Year").toIntOrNull() ?: year
            val name = listOf(f("Prefix"), f("First"), f("Last"), f("Suffix")).filter { it.isNotEmpty() }.joinToString(" ")
            out.add(Filing(doc, kind, FILING_TYPES[kind] ?: kind, f("Last"), f("First"), name, f("StateDst"), y, iso(f("FilingDate")), if (kind == "P") ptrUrl(y, doc) else fdUrl(y, doc)))
        }
        return out.sortedWith(compareByDescending<Filing> { it.filed ?: "" }.thenByDescending { it.docId })
    }

    fun memberMatch(row: Filing, member: String): Boolean {
        val m = member.trim().lowercase()
        if (m.isEmpty()) return true
        val last: String; val first: String
        if (m.contains(",")) {
            val p = m.split(",", limit = 2)
            last = p[0].trim(); first = p[1].trim()
        } else {
            val parts = m.split(Regex("\\s+"))
            last = parts.last(); first = parts.dropLast(1).joinToString(" ")
        }
        if (row.last.lowercase() != last) return false
        return first.isEmpty() || row.first.lowercase().startsWith(first)
    }
}
