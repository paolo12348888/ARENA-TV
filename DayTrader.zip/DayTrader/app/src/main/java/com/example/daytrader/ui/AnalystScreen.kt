package com.example.daytrader.ui

import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.example.daytrader.MainActivity
import com.example.daytrader.Sec
import com.example.daytrader.engine.Analyst
import com.example.daytrader.engine.EngineError
import com.example.daytrader.engine.Json
import com.example.daytrader.engine.Json.map

/** Bilanci trimestrali dai dati XBRL della SEC e cosa è cambiato. */
class AnalystScreen(act: MainActivity) : Screen(act) {
    private lateinit var sym: EditText
    private lateinit var status: TextView
    private lateinit var out: LinearLayout
    @Volatile private var running = false

    override fun build(): View {
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Bilanci"))
        col.addView(Ui.muted(ctx, "Ultimi trimestri di un'azienda USA: fatturato, utile, margini e variazioni. Richiede nome ed email in Impostazioni (obbligo della SEC)."))
        sym = Ui.input(ctx, "Titolo (es. TSLA)", "TSLA").also { it.inputType = it.inputType or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS }
        col.addView(sym)
        col.addView(Ui.button(ctx, "Analizza") { go() })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        out = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(out)
        col.addView(Ui.spacer(ctx, 12))
        col.addView(Ui.muted(ctx, Ui.DISCLAIMER))
        return scrolling(col)
    }

    private fun go() {
        if (running) return
        val t = sym.text.toString().trim().uppercase()
        if (t.isEmpty()) return
        running = true
        out.removeAllViews()
        status.setTextColor(Ui.MUTED); status.text = "Scarico i dati della SEC…"
        act.bg {
            try {
                val cik = Sec.ciks(act.store)[t] ?: throw EngineError("$t non risulta nell'elenco SEC (solo aziende USA).")
                val cf = Json.parse(Sec.companyFacts(act.store, cik)).map() ?: throw EngineError("Dati SEC non validi.")
                val res = Analyst.analyse(cf, 6)
                act.ui { status.text = ""; show(t, res) }
            } catch (e: Exception) {
                act.ui { status.setTextColor(Ui.BAD); status.text = e.message ?: e.javaClass.simpleName }
            } finally { running = false }
        }
    }

    private fun show(t: String, res: com.example.daytrader.engine.AnalystResult) {
        out.removeAllViews()
        out.addView(Ui.section(ctx, "${res.entity ?: t} (${t})"))
        val c = Ui.card(ctx)
        for (s in Analyst.changes(res)) c.addView(Ui.text(ctx, "• $s", 13f).apply { setPadding(0, 0, 0, Ui.dp(ctx, 4)) })
        out.addView(c)
        out.addView(Ui.section(ctx, "Trimestri"))
        for (r in res.rows) {
            val k = Ui.card(ctx)
            k.addView(Ui.text(ctx, "${r.end}  (${r.fiscal}${if (r.derived) ", ricavato" else ""})", 14f, Ui.TEXT, true))
            k.addView(Ui.row(ctx, "Fatturato", Analyst.money(r.revenue)))
            k.addView(Ui.row(ctx, "Utile netto", Analyst.money(r.netIncome)))
            r.epsDiluted?.let { k.addView(Ui.row(ctx, "Utile per azione", "%.2f $".format(it))) }
            r.revenueYoy?.let { k.addView(Ui.row(ctx, "Fatturato su 1 anno", "%+.1f%%".format(it), if (it >= 0) Ui.ACCENT else Ui.BAD)) }
            out.addView(k)
        }
        if (res.ttm.isNotEmpty()) {
            val k = Ui.card(ctx)
            k.addView(Ui.text(ctx, "Ultimi 12 mesi", 14f, Ui.TEXT, true))
            for ((a, b) in res.ttm) k.addView(Ui.row(ctx, a, if (a.startsWith("eps")) "%.2f $".format(b) else Analyst.money(b)))
            out.addView(k)
        }
    }
}
