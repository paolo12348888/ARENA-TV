package com.example.daytrader.ui

import android.content.Context
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import com.example.daytrader.MainActivity
import com.example.daytrader.engine.TimeUtil

/** Una schermata dell'app: costruisce la sua vista una volta sola. */
abstract class Screen(val act: MainActivity) {
    val ctx: Context get() = act
    private var built: View? = null

    abstract fun build(): View

    fun view(): View {
        val v = built ?: build()
        built = v
        return v
    }

    open fun onShown() {}

    /** Una colonna scorrevole con i margini giusti. */
    protected fun scrolling(content: LinearLayout): View {
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 24))
        return ScrollView(ctx).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(content, LinearLayout.LayoutParams(-1, -2))
        }
    }

    protected fun spinner(items: List<String>): Spinner = Spinner(ctx).apply {
        adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, items)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4)) }
    }

    protected fun num(s: String): Double? = s.trim().replace(",", ".").toDoubleOrNull()

    /** (giorno, orario) di default: la sessione in corso, oppure l'ultima conclusa (modalità replay). */
    protected fun defaultSession(): Pair<String, String> {
        val now = TimeUtil.nowNy()
        var d = now.toLocalDate()
        val m = TimeUtil.minutesOf(now)
        val tradingToday = TimeUtil.closedReason(d) == null
        if (tradingToday && m >= TimeUtil.OPEN_MIN) {
            val close = TimeUtil.closeMin(d.toString())
            val t = if (m >= close) close else (m / 5) * 5
            return Pair(d.toString(), TimeUtil.clock24(t))
        }
        d = d.minusDays(1)
        var guard = 0
        while (TimeUtil.closedReason(d) != null && guard < 15) { d = d.minusDays(1); guard++ }
        return Pair(d.toString(), TimeUtil.clock24(TimeUtil.closeMin(d.toString())))
    }
}
