package com.example.daytrader.engine

data class TmPlan(
    val symbol: String, val date: String, val entry: Double, val stop: Double, val target: Double,
    val entryBar: Int, val stopRule: String, val orMinutes: Int = 15
)

data class McResult(
    val replays: Int, val seed: Int, val barsLeft: Int,
    val pTarget: Double, val pStop: Double, val pNeither: Double, val pGreen: Double,
    val medianClose: Double, val p5Close: Double, val p95Close: Double, val avgR: Double, val rAtTarget: Double,
    val bands: List<List<Double>>, val samplePaths: List<List<Double>>,
    val histLo: Double, val histHi: Double, val histBins: List<Int>
)

data class HistTrade(val date: String, val time: String, val entry: Double, val stop: Double, val target: Double, val outcome: String, val r: Double)

data class HistResult(
    val sessions: Int, val triggered: Int, val target: Int, val stop: Int, val close: Int, val green: Int,
    val avgR: Double?, val trades: List<HistTrade>
)

enum class Lean { COIN_FLIP, BREAK_EVEN, LEANS_TARGET, LEANS_STOP, STRONG_TARGET, STRONG_STOP, NONE }

data class TmResult(
    val plan: TmPlan, val mc: McResult, val history: HistResult, val lean: Lean,
    val share: Double, val breakEven: Double, val poolSessions: Int, val poolFrom: String, val poolTo: String,
    val untilMin: Int, val warnings: List<String>
)

/** Time Machine: 10.000 repliche + storico reale (porting di trader-timemachine). */
object TimeMachine {
    const val SAMPLE_PATHS = 160
    const val BAND_PATHS = 2000
    val BAND_Q = doubleArrayOf(0.05, 0.25, 0.5, 0.75, 0.95)
    const val HIST_BINS = 24
    const val COIN_FLIP = 0.05
    const val STRONG = 0.15
    const val MANY_NEITHER = 0.40
    const val MIN_SESSIONS = 20
    const val SB = Market.SESSION_BARS

    /** Sessioni complete (78 candele) PRIMA della data del piano. */
    fun fullSessions(days: Map<String, Map<Int, Bar>>, before: String): List<Pair<String, List<Bar>>> {
        val out = ArrayList<Pair<String, List<Bar>>>()
        for (d in days.keys.sorted()) {
            if (d >= before) continue
            val s = days[d]!!
            if (s.size == SB) out.add(Pair(d, (0 until SB).map { s[it]!! }))
        }
        return out
    }

    fun buildPool(sessions: List<Pair<String, List<Bar>>>): Array<Array<DoubleArray>> {
        return Array(SB) { i ->
            if (i == 0) emptyArray()
            else Array(sessions.size) { j ->
                val d = sessions[j].second
                val pc = d[i - 1].c
                doubleArrayOf(d[i].o / pc, d[i].h / pc, d[i].l / pc, d[i].c / pc)
            }
        }
    }

    private fun pct(a: DoubleArray, q: Double) = a[minOf(a.size - 1, (q * a.size).toInt())]

    fun simulate(
        pool: Array<Array<DoubleArray>>, entry: Double, stop: Double, target: Double, k: Int, last: Int,
        replays: Int = 10000, seed: Int = 19, window: Int = 2
    ): McResult {
        val risk = entry - stop
        val rTarget = Num.pyRound((target - entry) / risk, 4)

        fun slot(rng: PyRandom, i: Int): Int =
            if (window == 0) i else minOf(SB - 1, maxOf(1, i + rng.randInt(-window, window)))

        fun draw(rng: PyRandom, i: Int): DoubleArray {
            val arr = pool[slot(rng, i)]
            return arr[rng.randBelow(arr.size)]
        }

        var rng = PyRandom(seed)
        val outcomes = IntArray(replays) // 0 target, 1 stop, 2 close
        val closes = DoubleArray(replays)
        val paths = ArrayList<List<Double>>()
        for (n in 0 until replays) {
            var p = entry
            var outcome = -1
            val keep = n < SAMPLE_PATHS
            val path = ArrayList<Double>()
            if (keep) path.add(entry)
            for (i in k + 1..last) {
                val bar = draw(rng, i)
                val hi = p * bar[1]; val lo = p * bar[2]; val cl = p * bar[3]
                if (outcome == -1) {
                    if (lo <= stop) outcome = 1
                    else if (hi >= target) outcome = 0
                }
                p = cl
                if (keep) path.add(Num.pyRound2(p))
            }
            outcomes[n] = if (outcome == -1) 2 else outcome
            closes[n] = p
            if (keep) paths.add(path)
        }
        var nT = 0; var nS = 0; var nC = 0; var green = 0
        var sumR = 0.0
        for (n in 0 until replays) {
            when (outcomes[n]) { 0 -> nT++; 1 -> nS++; else -> nC++ }
            if (outcomes[n] == 0 || (outcomes[n] == 2 && closes[n] > entry)) green++
            sumR += when (outcomes[n]) { 0 -> rTarget; 1 -> -1.0; else -> (closes[n] - entry) / risk }
        }
        val srt = closes.copyOf(); srt.sort()

        rng = PyRandom(seed)
        val len = last - k + 1
        val cols = Array(len) { DoubleArray(BAND_PATHS) }
        for (n in 0 until BAND_PATHS) {
            var p = entry
            cols[0][n] = entry
            var j = 1
            for (i in k + 1..last) {
                val bar = draw(rng, i)
                p *= bar[3]
                cols[j][n] = p
                j++
            }
        }
        val bands = ArrayList<List<Double>>()
        for (j in 0 until len) {
            val col = cols[j]; col.sort()
            bands.add(BAND_Q.map { Num.pyRound2(pct(col, it)) })
        }
        val lo = pct(srt, 0.01); val hi = pct(srt, 0.99)
        val w = (hi - lo) / HIST_BINS
        val bins = IntArray(HIST_BINS)
        for (c in srt) {
            val b = if (w > 0) ((c - lo) / w).toInt() else 0
            if (b in 0 until HIST_BINS) bins[b]++
        }
        return McResult(
            replays, seed, last - k,
            Num.pyRound(nT.toDouble() / replays, 4), Num.pyRound(nS.toDouble() / replays, 4),
            Num.pyRound(nC.toDouble() / replays, 4), Num.pyRound(green.toDouble() / replays, 4),
            Num.pyRound2(pct(srt, 0.5)), Num.pyRound2(pct(srt, 0.05)), Num.pyRound2(pct(srt, 0.95)),
            Num.pyRound(sumR / replays, 3), rTarget, bands, paths, Num.pyRound2(lo), Num.pyRound2(hi), bins.toList()
        )
    }

    private fun openingRange(d: List<Bar>, n: Int): Pair<Double, Double> =
        Pair((0 until n).maxOf { d[it].h }, (0 until n).minOf { d[it].l })

    fun historyReplay(
        sessions: List<Pair<String, List<Bar>>>, stopRule: String, stopPct: Double, orMinutes: Int, targetR: Double, last: Int
    ): HistResult {
        val n = orMinutes / 5
        val trades = ArrayList<HistTrade>()
        for ((d, D) in sessions) {
            val (oh, ol) = openingRange(D, n)
            var kk = -1
            for (i in n..last) if (D[i].c > oh) { kk = i; break }
            if (kk < 0) continue
            val e = Num.pyRound2(D[kk].c)
            val s = when (stopRule) {
                "or_mid" -> Num.floorCents((oh + ol) / 2)
                "or_low" -> Num.floorCents(ol)
                else -> Num.floorCents(e * (1 - stopPct / 100.0))
            }
            val risk = e - s
            if (risk <= 0) continue
            val t = Num.pyRound2(e + targetR * risk)
            var oc = -1
            for (b in D.subList(kk + 1, last + 1)) {
                if (b.l <= s) { oc = 1; break }
                if (b.h >= t) { oc = 0; break }
            }
            val cl = D[last].c
            val r = when (oc) { 0 -> (t - e) / risk; 1 -> -1.0; else -> (cl - e) / risk }
            trades.add(HistTrade(d, TimeUtil.clock12(TimeUtil.OPEN_MIN + 5 * (kk + 1)), e, s, t,
                when (oc) { 0 -> "target"; 1 -> "stop"; else -> "close" }, Num.pyRound2(r)))
        }
        return HistResult(
            sessions.size, trades.size, trades.count { it.outcome == "target" }, trades.count { it.outcome == "stop" },
            trades.count { it.outcome == "close" }, trades.count { it.r > 0 },
            if (trades.isEmpty()) null else Num.pyRound(trades.map { it.r }.average(), 3), trades
        )
    }

    fun lean(mc: McResult): Triple<Double, Double, Double>? {
        val pt = mc.pTarget; val ps = mc.pStop
        if (pt + ps <= 0) return null
        val r = if (mc.rAtTarget != 0.0) mc.rAtTarget else 1.0
        val share = pt / (pt + ps)
        val even = 1.0 / (1.0 + r)
        return Triple(share - even, share, even)
    }

    fun classify(mc: McResult): Lean {
        val lv = lean(mc) ?: return Lean.NONE
        val d = lv.first
        val oneR = Math.abs(mc.rAtTarget - 1.0) < 0.005
        return when {
            Math.abs(d) < COIN_FLIP -> if (oneR) Lean.COIN_FLIP else Lean.BREAK_EVEN
            Math.abs(d) < STRONG -> if (d > 0) Lean.LEANS_TARGET else Lean.LEANS_STOP
            else -> if (d > 0) Lean.STRONG_TARGET else Lean.STRONG_STOP
        }
    }

    fun run(
        plan: TmPlan, bars: List<Bar>, untilMin: Int? = null, replays: Int = 10000, seed: Int = 19, window: Int = 2
    ): TmResult {
        if (bars.isEmpty()) throw EngineError("Nessuna candela da 5 minuti completa per ${plan.symbol}.")
        val endMin = TimeUtil.closeMin(plan.date)
        val until = untilMin ?: endMin
        if ((until - TimeUtil.OPEN_MIN) % 5 != 0 || until > endMin) throw EngineError("L'orario finale deve stare sulla griglia dei 5 minuti e non oltre la chiusura.")
        val last = (until - TimeUtil.OPEN_MIN) / 5 - 1
        val k = plan.entryBar
        if (last <= k) throw EngineError("L'orario finale non lascia candele da simulare dopo l'ingresso.")
        val days = Market.splitSessions(bars)
        val entryDay = days[plan.date] ?: emptyMap()
        val eb = entryDay[k] ?: throw EngineError("L'ingresso non è nei dati: manca la candela completa delle ${TimeUtil.clock24(TimeUtil.OPEN_MIN + 5 * k)} del ${plan.date}.")
        val warn = ArrayList<String>()
        if (plan.entry < eb.l - 0.01 || plan.entry > eb.h + 0.01) {
            warn.add("L'ingresso %.2f è fuori dal range di quella candela (%.2f - %.2f).".format(plan.entry, eb.l, eb.h))
        }
        val sessions = fullSessions(days, plan.date)
        if (sessions.size < MIN_SESSIONS) throw EngineError("Solo ${sessions.size} sessioni complete di ${plan.symbol} prima del ${plan.date}: ne servono almeno $MIN_SESSIONS.")
        val pool = buildPool(sessions)
        val mc = simulate(pool, plan.entry, plan.stop, plan.target, k, last, replays, seed, window)
        val risk = plan.entry - plan.stop
        val targetR = Num.pyRound2((plan.target - plan.entry) / risk)
        val stopRule = when (plan.stopRule) {
            "or_mid" -> "or_mid"
            "or_low" -> "or_low"
            else -> "pct"
        }
        val hist = historyReplay(sessions, stopRule, Num.pyRound(100.0 * Num.pyRound2(risk) / plan.entry, 4), plan.orMinutes, targetR, last)
        val lv = lean(mc)
        return TmResult(
            plan, mc, hist, classify(mc), lv?.second ?: 0.0, lv?.third ?: 0.0,
            sessions.size, sessions.first().first, sessions.last().first, until, warn
        )
    }
}
