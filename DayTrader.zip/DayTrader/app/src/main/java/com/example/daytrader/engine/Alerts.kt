package com.example.daytrader.engine

import java.time.LocalDateTime

/** Regola di avviso: above/target, below/stop, pct_move, opening_bell, time. */
data class AlertRule(
    val id: String, val type: String, val symbol: String = "", val price: Double? = null, val pct: Double? = null,
    val direction: String = "", val at: String = "", val beforeClose: Boolean = false,
    val date: String = "", val label: String = "", val note: String = "", val rearm: Boolean = false, val ref: Double? = null
)

data class Quote(val symbol: String, val price: Double, val prevClose: Double?)
data class Ring(val ruleId: String, val title: String, val body: String)

object Alerts {
    /** Ritorna gli avvisi scattati e lo stato aggiornato (id -> data/etichetta dell'ultimo scatto). */
    fun check(rules: List<AlertRule>, quotes: Map<String, Quote>, nowNy: LocalDateTime, state: Map<String, String>): Pair<List<Ring>, Map<String, String>> {
        val st = HashMap(state)
        val rings = ArrayList<Ring>()
        val today = nowNy.toLocalDate().toString()
        val closed = TimeUtil.closedReason(nowNy.toLocalDate()) != null
        val mins = TimeUtil.minutesOf(nowNy)
        val closeMin = TimeUtil.closeMin(today)
        val open = !closed && mins >= TimeUtil.OPEN_MIN && mins < closeMin
        for (r in rules) {
            if (r.date.isNotEmpty() && r.date != today) continue
            when (r.type) {
                "opening_bell" -> {
                    if (open && st[r.id] != today) {
                        st[r.id] = today
                        rings.add(Ring(r.id, "Il mercato è aperto", "La NYSE ha aperto alle 9:30 (ora di New York)."))
                    }
                }
                "time" -> {
                    var at = TimeUtil.parseClock(r.at) ?: continue
                    if (r.beforeClose && TimeUtil.isEarly(today)) at -= 180
                    if (!closed && mins >= at && st[r.id] != today) {
                        st[r.id] = today
                        rings.add(Ring(r.id, r.label.ifEmpty { "Orario raggiunto" }, "Sono passate le ${TimeUtil.clock24(at)} a New York."))
                    }
                }
                "above", "target", "below", "stop" -> {
                    val q = quotes[r.symbol] ?: continue
                    val p = r.price ?: continue
                    if (!open) continue
                    val up = r.type == "above" || r.type == "target"
                    val hit = if (up) q.price >= p else q.price <= p
                    if (hit && st[r.id] != "fired") {
                        st[r.id] = "fired"
                        val what = when (r.type) { "target" -> "TARGET raggiunto"; "stop" -> "STOP raggiunto"; "above" -> "sopra il prezzo"; else -> "sotto il prezzo" }
                        rings.add(Ring(r.id, "${r.symbol}: $what", "%s a %.2f $ (soglia %.2f $).%s".format(r.symbol, q.price, p, if (r.note.isNotEmpty()) " " + r.note else "")))
                    } else if (!hit && r.rearm && st[r.id] == "fired") {
                        st.remove(r.id)
                    }
                }
                "pct_move" -> {
                    val q = quotes[r.symbol] ?: continue
                    val th = r.pct ?: continue
                    if (!open) continue
                    val ref = r.ref ?: q.prevClose ?: continue
                    if (ref == 0.0) continue
                    val move = 100.0 * (q.price - ref) / ref
                    val dirOk = when (r.direction) { "up" -> move > 0; "down" -> move < 0; else -> true }
                    if (dirOk && Math.abs(move) >= th && st[r.id] != today) {
                        st[r.id] = today
                        rings.add(Ring(r.id, "${r.symbol}: movimento del %+.1f%%".format(move), "%s a %.2f $ rispetto a %.2f $.".format(r.symbol, q.price, ref)))
                    }
                }
            }
        }
        return Pair(rings, st)
    }

    /** Regole da un piano di uscita: stop, target e uscita entro la chiusura (solo per il giorno del piano). */
    fun fromPlan(p: ExitPlan, date: String): List<AlertRule> {
        val s = p.symbol.lowercase() + "-" + date
        return listOf(
            AlertRule("$s-stop", "stop", p.symbol, p.stop, date = date, note = "stop del piano: ${p.stopLabel}"),
            AlertRule("$s-target", "target", p.symbol, p.target, date = date, note = "target del piano: %sR".format(p.targetR)),
            AlertRule("$s-flat", "time", p.symbol, at = p.flatBy, label = "${p.symbol}: esci entro la chiusura", beforeClose = true, date = date)
        )
    }

    fun parseQuote(json: String, symbol: String): Quote {
        val m = News.parseMove(json, symbol)
        return Quote(symbol, m.price, m.prevClose)
    }
}
