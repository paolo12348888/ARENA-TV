package com.example.daytrader.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Colori e piccoli costruttori di viste (tutto in codice, nessun file XML). */
object Ui {
    val BG = Color.parseColor("#0E1117")
    val CARD = Color.parseColor("#171B24")
    val ACCENT = Color.parseColor("#3DDC97")
    val WARN = Color.parseColor("#FFB020")
    val BAD = Color.parseColor("#FF5C5C")
    val TEXT = Color.parseColor("#E6EAF2")
    val MUTED = Color.parseColor("#8B93A7")
    val LINE = Color.parseColor("#2A3040")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusDp: Int, ctx: Context): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(ctx, radiusDp).toFloat()
    }

    fun text(ctx: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun title(ctx: Context, s: String): TextView = text(ctx, s, 20f, TEXT, true).apply {
        setPadding(0, dp(ctx, 4), 0, dp(ctx, 8))
    }

    fun section(ctx: Context, s: String): TextView = text(ctx, s.uppercase(), 12f, MUTED, true).apply {
        setPadding(0, dp(ctx, 14), 0, dp(ctx, 6))
    }

    fun muted(ctx: Context, s: String, size: Float = 12f): TextView = text(ctx, s, size, MUTED)

    fun card(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 12, ctx)
        setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(ctx, 6), 0, dp(ctx, 6)) }
    }

    fun button(ctx: Context, label: String, color: Int = ACCENT, onClick: () -> Unit): Button =
        Button(ctx).apply {
            text = label
            isAllCaps = false
            setTextColor(if (color == ACCENT) Color.BLACK else Color.WHITE)
            background = rounded(color, 10, ctx)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(ctx, 48)).apply { setMargins(0, dp(ctx, 6), 0, dp(ctx, 6)) }
        }

    fun input(ctx: Context, hint: String, value: String = "", number: Boolean = false, decimal: Boolean = true): EditText =
        EditText(ctx).apply {
            this.hint = hint
            setText(value)
            setTextColor(TEXT)
            setHintTextColor(MUTED)
            background = rounded(Color.parseColor("#1F2430"), 8, ctx)
            setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
            isSingleLine = true
            if (number) {
                inputType = InputType.TYPE_CLASS_NUMBER or (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(ctx, 4), 0, dp(ctx, 4)) }
        }

    fun row(ctx: Context, left: String, right: String, rightColor: Int = TEXT): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(ctx, 3), 0, dp(ctx, 3))
            addView(text(ctx, left, 14f, MUTED).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            addView(text(ctx, right, 14f, rightColor, true).apply { gravity = Gravity.END })
        }

    fun badge(ctx: Context, s: String, color: Int): TextView = text(ctx, s, 13f, Color.BLACK, true).apply {
        background = rounded(color, 8, ctx)
        setPadding(dp(ctx, 10), dp(ctx, 4), dp(ctx, 10), dp(ctx, 4))
        gravity = Gravity.CENTER
    }

    fun spacer(ctx: Context, h: Int = 8): View = View(ctx).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(ctx, h)) }

    fun money(x: Double): String = "%,.2f $".format(x)
    fun p2(x: Double): String = "%.2f".format(x)
    fun pctText(x: Double): String = "%.1f %%".format(x * 100)

    const val DISCLAIMER = "Strumento educativo, non consulenza finanziaria. Il day trading comporta un alto rischio di perdita: la maggior parte di chi lo pratica perde denaro. Dati gratuiti, ritardati e non ufficiali: non usarli per decisioni di temporizzazione. Un ordine non viene mai inviato da questa app."
}
