package com.example.daytrader.ui

import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.example.daytrader.Http
import com.example.daytrader.MainActivity
import com.example.daytrader.Sec
import com.example.daytrader.Yahoo
import com.example.daytrader.engine.Move
import com.example.daytrader.engine.NewsItem
import com.example.daytrader.engine.News
import com.example.daytrader.engine.TimeUtil

/** Notizie e comunicati SEC (8-K) dei titoli indicati e movimento di oggi. */
class NewsScreen(act: MainActivity) : Screen(act) {
    private lateinit var tickers: EditText
    private lateinit var hours: EditText
    private lateinit var status: TextView
    private lateinit var out: LinearLayout
    @Volatile private var running = false

    override fun build(): View {
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Notizie"))
        col.addView(Ui.muted(ctx, "Titoli e comunicati SEC degli ultimi giorni, con ciò che può muovere il prezzo. Vuoto = la tua lista (max 15 titoli per volta)."))
        tickers = Ui.input(ctx, "Titoli separati da virgola (es. TSLA, AAPL)", "")
        hours = Ui.input(ctx, "Ore indietro", "24", number = true, decimal = false)
        col.addView(tickers); col.addView(hours)
        col.addView(Ui.button(ctx, "Cerca notizie") { go() })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        out = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(out)
        col.addView(Ui.spacer(ctx, 12))
        col.addView(Ui.muted(ctx, Ui.DISCLAIMER))
        return scrolling(col)
    }

    private fun say(s: String, err: Boolean = false) = act.ui { status.setTextColor(if (err) Ui.BAD else Ui.MUTED); status.text = s }

    private fun go() {
        if (running) return
        val typed = tickers.text.toString().split(",", " ").map { it.trim().uppercase() }.filter { it.isNotEmpty() }.distinct()
        val list = (if (typed.isEmpty()) act.store.watchlist else typed).take(15)
        val h = hours.text.toString().trim().toIntOrNull() ?: 24
        running = true
        out.removeAllViews()
        act.bg {
            try {
                val items = ArrayList<NewsItem>()
                val moves = ArrayList<Move>()
                var ciks: Map<String, String>? = null
                var secNote = ""
                if (act.store.hasSecUa()) { try { ciks = Sec.ciks(act.store) } catch (e: Exception) { secNote = "SEC non raggiungibile: ${e.message}" } }
                else secNote = "Comunicati SEC esclusi: inserisci nome ed email in Impostazioni."
                for ((i, t) in list.withIndex()) {
                    say("Leggo $t (${i + 1}/${list.size})…")
                    try { items.addAll(News.parseRss(Http.text(News.yahooUrl(t)), t)) } catch (e: Exception) { }
                    val cik = ciks?.get(t)
                    if (cik != null) {
                        try { items.addAll(News.parseSecAtom(Http.text(News.secFeedUrl(cik, "8-K"), Sec.ua(act.store)), t)) } catch (e: Exception) { }
                        try { Thread.sleep(150) } catch (e: InterruptedException) { }
                    }
                    try { moves.add(News.parseMove(Yahoo.chart(t, "1d", "5m"), t)) } catch (e: Exception) { }
                }
                val watch = list.associateWith { "" }
                val now = System.currentTimeMillis() / 1000
                val sel = News.select(News.dedupe(News.tag(items, watch)), now, h)
                act.ui { status.text = ""; show(sel, moves, secNote) }
            } catch (e: Exception) {
                say(e.message ?: e.javaClass.simpleName, true)
            } finally { running = false }
        }
    }

    private fun show(items: List<NewsItem>, moves: List<Move>, note: String) {
        out.removeAllViews()
        if (note.isNotEmpty()) out.addView(Ui.muted(ctx, note, 13f))
        val big = moves.filter { Math.abs(it.pct) >= News.MOVE_PCT }
        if (big.isNotEmpty()) {
            out.addView(Ui.section(ctx, "Si stanno muovendo"))
            for (m in big.sortedByDescending { Math.abs(it.pct) }) {
                out.addView(Ui.row(ctx, m.ticker, "%+.2f%%  (%.2f $)".format(m.pct, m.price), if (m.pct >= 0) Ui.ACCENT else Ui.BAD))
            }
        }
        out.addView(Ui.section(ctx, "Notizie: ${items.size}"))
        for (n in items.take(80)) {
            val c = Ui.card(ctx)
            val whenTxt = n.time?.let { TimeUtil.toNy(it).let { d -> "%02d/%02d %02d:%02d NY".format(d.dayOfMonth, d.monthValue, d.hour, d.minute) } } ?: ""
            c.addView(Ui.muted(ctx, "${n.ticker} · ${n.source} · $whenTxt"))
            c.addView(Ui.text(ctx, n.title, 14f, if (n.important) Ui.WARN else Ui.TEXT, true))
            if (n.tags.isNotEmpty()) c.addView(Ui.muted(ctx, n.tags.joinToString(" · ")))
            if (n.link.isNotEmpty()) c.setOnClickListener {
                try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link))) } catch (e: Exception) { }
            }
            out.addView(c)
        }
        if (items.isEmpty()) out.addView(Ui.muted(ctx, "Nessuna notizia in questo periodo."))
    }
}
