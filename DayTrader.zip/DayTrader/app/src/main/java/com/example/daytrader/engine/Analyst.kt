package com.example.daytrader.engine

import com.example.daytrader.engine.Json.dbl
import com.example.daytrader.engine.Json.list
import com.example.daytrader.engine.Json.map
import com.example.daytrader.engine.Json.str
import java.time.LocalDate

data class QPoint(
    val value: Double, val start: String, val end: String, val derived: Boolean,
    val fy: String?, val fp: String?, val form: String?, val filed: String?, val concept: String = ""
)

data class QRow(
    val end: String, val start: String?, val fiscal: String, val derived: Boolean,
    val revenue: Double?, val grossProfit: Double?, val operatingIncome: Double?, val netIncome: Double?, val epsDiluted: Double?,
    val grossMargin: Double?, val operatingMargin: Double?, val netMargin: Double?,
    val revenueYoy: Double?, val netIncomeYoy: Double?, val epsYoy: Double?, val filed: String?, val form: String?
)

data class AnalystResult(val entity: String?, val cik: String, val rows: List<QRow>, val ttm: Map<String, Double>)

/** Bilanci trimestrali dai dati XBRL pubblici della SEC (porting di trader-analyst). */
object Analyst {
    private val CONCEPTS = linkedMapOf(
        "revenue" to listOf("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "RevenuesNetOfInterestExpense",
            "RevenueFromContractWithCustomerIncludingAssessedTax", "SalesRevenueNet", "SalesRevenueGoodsNet", "SalesRevenueServicesNet"),
        "cost_of_revenue" to listOf("CostOfGoodsAndServicesSold", "CostOfRevenue", "CostOfGoodsSold"),
        "gross_profit" to listOf("GrossProfit"),
        "operating_income" to listOf("OperatingIncomeLoss"),
        "net_income" to listOf("NetIncomeLoss", "ProfitLoss", "NetIncomeLossAvailableToCommonStockholdersBasic"),
        "eps_diluted" to listOf("EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted")
    )

    private fun date(s: String) = LocalDate.parse(s)

    private fun factsFor(cf: Map<String, Any?>, concept: String, unitHint: String): List<Map<String, Any?>> {
        val node = cf["facts"].map()?.get("us-gaap").map()?.get(concept).map() ?: return emptyList()
        val units = node["units"].map() ?: return emptyList()
        val unit = if (unitHint in units) unitHint else units.keys.firstOrNull() ?: return emptyList()
        return (units[unit].list() ?: emptyList()).mapNotNull { it.map() }
    }

    private fun periods(facts: List<Map<String, Any?>>): Map<Pair<String, String>, Map<String, Any?>> {
        val latest = LinkedHashMap<Pair<String, String>, Map<String, Any?>>()
        val first = HashMap<Pair<String, String>, Map<String, Any?>>()
        fun stamp(f: Map<String, Any?>) = (f["filed"].str() ?: "") + "\u0000" + (f["accn"].str() ?: "")
        for (f in facts) {
            val start = f["start"].str() ?: continue
            val end = f["end"].str() ?: continue
            val form = (f["form"].str() ?: "").split("/")[0]
            if (form !in listOf("10-Q", "10-K", "20-F", "40-F")) continue
            val key = Pair(start, end)
            val st = stamp(f)
            if (key !in latest || st > stamp(latest[key]!!)) latest[key] = f
            if (key !in first || st < stamp(first[key]!!)) first[key] = f
        }
        val out = LinkedHashMap<Pair<String, String>, Map<String, Any?>>()
        for ((key, f) in latest) {
            val g = LinkedHashMap(f)
            g["fy"] = first[key]!!["fy"]
            g["fp"] = first[key]!!["fp"]
            out[key] = g
        }
        return out
    }

    private fun fyStr(v: Any?): String? = when (v) { is Double -> v.toLong().toString(); is String -> v; else -> null }

    private fun quarterly(facts: List<Map<String, Any?>>, deriveQ4: Boolean): Map<String, QPoint> {
        val per = periods(facts)
        val q = LinkedHashMap<String, QPoint>()
        val years = ArrayList<Triple<String, String, Map<String, Any?>>>()
        for ((k, f) in per) {
            val (start, end) = k
            val days = java.time.temporal.ChronoUnit.DAYS.between(date(start), date(end)).toInt()
            val v = f["val"].dbl() ?: continue
            if (days in 80..100) {
                q[end] = QPoint(v, start, end, false, fyStr(f["fy"]), f["fp"].str(), f["form"].str(), f["filed"].str())
            } else if (days in 350..380) {
                years.add(Triple(start, end, f))
            }
        }
        if (deriveQ4) {
            for ((start, end, f) in years) {
                if (end in q) continue
                val inside = q.values.filter { it.start >= start && it.end < end }.sortedBy { it.end }
                if (inside.size != 3) continue
                val lastQStart = date(inside.last().end).plusDays(1)
                val v = f["val"].dbl() ?: continue
                q[end] = QPoint(v - inside.sumOf { it.value }, lastQStart.toString(), end, true, fyStr(f["fy"]), "Q4", f["form"].str(), f["filed"].str())
            }
        }
        return q
    }

    private fun series(cf: Map<String, Any?>, key: String): Map<String, QPoint> {
        val unit = if (key == "eps_diluted") "USD/shares" else "USD"
        val merged = LinkedHashMap<String, QPoint>()
        for (concept in CONCEPTS[key]!!) {
            val q = quarterly(factsFor(cf, concept, unit), true)
            if (q.isEmpty()) continue
            for ((end, v) in q) if (end !in merged) merged[end] = v.copy(concept = concept)
        }
        return merged
    }

    private fun yoy(s: Map<String, QPoint>, end: String, days: Int = 365, slack: Int = 10): QPoint? {
        val target = date(end).minusDays(days.toLong())
        var best: Pair<Long, String>? = null
        for (e in s.keys) {
            val gap = Math.abs(java.time.temporal.ChronoUnit.DAYS.between(date(e), target))
            if (gap <= slack && (best == null || gap < best.first)) best = Pair(gap, e)
        }
        return best?.let { s[it.second] }
    }

    fun pct(a: Double?, b: Double?): Double? {
        if (a == null || b == null || b == 0.0) return null
        return Num.pyRound(100.0 * (a - b) / Math.abs(b), 1)
    }

    private fun margin(part: Double?, whole: Double?): Double? {
        if (part == null || whole == null || whole == 0.0) return null
        return Num.pyRound(100.0 * part / whole, 1)
    }

    fun analyse(cf: Map<String, Any?>, quarters: Int = 6, name: String? = null): AnalystResult {
        val s = HashMap<String, Map<String, QPoint>>()
        for (k in CONCEPTS.keys) s[k] = series(cf, k)
        val rev = s["revenue"]!!
        val ni = s["net_income"]!!
        if (rev.isEmpty() && ni.isEmpty()) throw EngineError("Nessun fatturato o utile trimestrale nei dati XBRL.")
        val ends = (rev.keys + ni.keys).toSortedSet().reversed().take(quarters)
        val rows = ArrayList<QRow>()
        for (end in ends) {
            val r = rev[end]?.value
            var gp = s["gross_profit"]!![end]?.value
            if (gp == null && r != null && end in s["cost_of_revenue"]!!) gp = r - s["cost_of_revenue"]!![end]!!.value
            val oi = s["operating_income"]!![end]?.value
            val n = ni[end]?.value
            val eps = s["eps_diluted"]!![end]?.value
            val pRev = yoy(rev, end); val pNi = yoy(ni, end); val pEps = yoy(s["eps_diluted"]!!, end)
            val base = rev[end] ?: ni[end]
            rows.add(QRow(
                end, base?.start, "${base?.fp ?: ""} ${base?.fy ?: ""}",
                listOf("revenue", "net_income").any { s[it]!![end]?.derived == true },
                r, gp, oi, n, eps?.let { Num.pyRound2(it) },
                margin(gp, r), margin(oi, r), margin(n, r),
                pct(r, pRev?.value), pct(n, pNi?.value), pct(eps, pEps?.value), base?.filed, base?.form
            ))
        }
        val ttm = LinkedHashMap<String, Double>()
        for (key in listOf("revenue", "net_income", "eps_diluted")) {
            val last4 = s[key]!!.keys.sorted().takeLast(4)
            if (last4.size == 4 && java.time.temporal.ChronoUnit.DAYS.between(date(last4.first()), date(last4.last())) < 300) {
                ttm[key] = last4.sumOf { s[key]!![it]!!.value }
            }
        }
        ttm["eps_diluted"]?.let { ttm["eps_diluted"] = Num.pyRound2(it) }
        return AnalystResult(name ?: cf["entityName"].str(), (cf["cik"].dbl()?.toLong()?.toString() ?: cf["cik"].str() ?: "").padStart(10, '0'), rows, ttm)
    }

    fun money(v: Double?): String = when {
        v == null -> "n/d"
        Math.abs(v) >= 1e9 -> "%.2f mld $".format(v / 1e9)
        else -> "%.1f mln $".format(v / 1e6)
    }

    /** Frasi in italiano su cosa è cambiato nell'ultimo trimestre. */
    fun changes(res: AnalystResult): List<String> {
        val rows = res.rows
        if (rows.isEmpty()) return emptyList()
        val cur = rows[0]
        val prev = rows.getOrNull(1)
        val out = ArrayList<String>()
        var line = "Trimestre chiuso il ${cur.end}${if (cur.derived) " (ricavato dal 10-K)" else ""}: fatturato ${money(cur.revenue)}"
        cur.revenueYoy?.let { line += " (%+.1f%% su un anno prima)".format(it) }
        line += ", utile netto ${money(cur.netIncome)}"
        cur.netIncomeYoy?.let { line += " (%+.1f%%)".format(it) }
        if (cur.epsDiluted != null) {
            line += ", utile per azione diluito %.2f $".format(cur.epsDiluted)
            cur.epsYoy?.let { line += " (%+.1f%%)".format(it) }
        }
        out.add("$line.")
        fun m(label: String, c: Double?, p: Double?) {
            if (c == null) return
            var s = "%s %.1f%%".format(label, c)
            if (prev != null && p != null) s += " (%+.1f punti sul trimestre prima)".format(c - p)
            out.add("$s.")
        }
        m("Margine lordo", cur.grossMargin, prev?.grossMargin)
        m("Margine operativo", cur.operatingMargin, prev?.operatingMargin)
        m("Margine netto", cur.netMargin, prev?.netMargin)
        if (cur.netIncome != null && cur.operatingIncome != null && cur.netIncome > cur.operatingIncome) {
            out.add("L'utile netto supera l'utile operativo: comprende guadagni esterni all'attività (investimenti, voci fiscali). Controlla il 10-Q prima di leggerlo come crescita.")
        }
        if (prev != null && cur.revenue != null && prev.revenue != null && prev.revenue != 0.0) {
            out.add("Fatturato %+.1f%% sul trimestre prima (molte attività sono stagionali: confronta prima con un anno fa).".format(pct(cur.revenue, prev.revenue)))
        }
        return out
    }
}
