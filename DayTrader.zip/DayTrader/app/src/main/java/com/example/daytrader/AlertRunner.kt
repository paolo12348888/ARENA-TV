package com.example.daytrader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.example.daytrader.engine.AlertRule
import com.example.daytrader.engine.Alerts
import com.example.daytrader.engine.EngineError
import com.example.daytrader.engine.Quote
import com.example.daytrader.engine.Ring
import com.example.daytrader.engine.TimeUtil

/** Un controllo degli avvisi: scarica i prezzi, applica le regole, manda le notifiche. */
object AlertRunner {
    const val CH_ALERTS = "alerts"
    const val CH_MONITOR = "monitor"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Avvisi di prezzo", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_MONITOR, "Controllo avvisi attivo", NotificationManager.IMPORTANCE_LOW))
    }

    fun notify(ctx: Context, ring: Ring) {
        ensureChannels(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = Notification.Builder(ctx, CH_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(ring.title)
            .setContentText(ring.body)
            .setStyle(Notification.BigTextStyle().bigText(ring.body))
            .setAutoCancel(true)
            .build()
        nm.notify(ring.ruleId.hashCode(), n)
    }

    /** Ritorna gli avvisi scattati (e li notifica se notify = true). */
    fun runOnce(ctx: Context, notifyUser: Boolean = true): List<Ring> {
        val store = Store(ctx)
        val rules = store.rules()
        if (rules.isEmpty()) return emptyList()
        val now = TimeUtil.nowNy()
        val today = now.toLocalDate().toString()
        val symbols = rules.filter { it.symbol.isNotEmpty() && it.type != "time" && (it.date.isEmpty() || it.date == today) }
            .map { it.symbol }.distinct()
        val quotes = HashMap<String, Quote>()
        for (s in symbols) {
            try {
                quotes[s] = Alerts.parseQuote(Yahoo.chart(s, "1d", "5m"), s)
            } catch (e: Exception) {
                // un prezzo mancante non ferma gli altri controlli
            }
            try { Thread.sleep(400) } catch (e: InterruptedException) { }
        }
        val (rings, st) = Alerts.check(rules, quotes, now, store.alertState())
        store.saveAlertState(st)
        if (notifyUser) rings.forEach { notify(ctx, it) }
        return rings
    }
}

/** Servizio in primo piano: controlla gli avvisi ogni minuto mentre il mercato è aperto. */
class AlertService : Service() {
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AlertRunner.ensureChannels(this)
        val n = Notification.Builder(this, AlertRunner.CH_MONITOR)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Day Trader: controllo avvisi attivo")
            .setContentText("Controllo i prezzi ogni minuto mentre il mercato USA è aperto.")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
        if (!running) {
            running = true
            worker = Thread {
                while (running) {
                    try {
                        val now = TimeUtil.nowNy()
                        val m = TimeUtil.minutesOf(now)
                        val open = TimeUtil.closedReason(now.toLocalDate()) == null && m >= TimeUtil.OPEN_MIN - 1 && m <= 16 * 60
                        if (open) AlertRunner.runOnce(this, true)
                    } catch (e: Exception) {
                        // si riprova al giro dopo
                    }
                    try { Thread.sleep(60000) } catch (e: InterruptedException) { break }
                }
            }.also { it.start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }
}
