package com.example.daytrader.ui

import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.example.daytrader.MainActivity
import com.example.daytrader.engine.Config

/** Le tue regole di rischio, la lista titoli e l'identificazione richiesta dalla SEC. */
class SettingsScreen(act: MainActivity) : Screen(act) {
    private lateinit var f: Map<String, EditText>
    private lateinit var ua: EditText
    private lateinit var watch: EditText
    private lateinit var status: TextView

    override fun build(): View {
        val c = act.store.config()
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Impostazioni"))
        col.addView(Ui.section(ctx, "Identificazione SEC"))
        col.addView(Ui.muted(ctx, "Per notizie 8-K e bilanci la SEC vuole nome ed email, per esempio: Mario Rossi mario@email.it"))
        ua = Ui.input(ctx, "Nome Cognome email", act.store.secUserAgent)
        col.addView(ua)
        col.addView(Ui.section(ctx, "Le tue regole di rischio"))
        fun field(key: String, label: String, v: String, number: Boolean = true): EditText {
            col.addView(Ui.muted(ctx, label))
            return Ui.input(ctx, label, v, number = number).also { col.addView(it) }
        }
        fun n(x: Double) = if (x == Math.floor(x)) x.toLong().toString() else x.toString()
        f = linkedMapOf(
            "budget" to field("budget", "Budget ($)", n(c.budget)),
            "buffer" to field("buffer", "Liquidità da non toccare (%)", n(c.cashBufferPct)),
            "pos" to field("pos", "Posizione massima (% del budget)", n(c.maxPositionPct)),
            "order" to field("order", "Ordine massimo ($)", n(c.maxOrderUsd)),
            "loss" to field("loss", "Perdita massima per operazione ($)", n(c.maxLossPerTrade)),
            "daily" to field("daily", "Perdita massima giornaliera ($)", n(c.maxDailyLoss)),
            "trades" to field("trades", "Operazioni massime al giorno", c.maxTradesPerDay.toString()),
            "rr" to field("rr", "Rendimento/rischio minimo", n(c.minRewardRisk)),
            "from" to field("from", "Nessun ingresso prima di (HH:MM NY)", c.noEntriesBefore, false),
            "to" to field("to", "Nessun ingresso dopo (HH:MM NY)", c.noEntriesAfter, false),
            "flat" to field("flat", "Esci entro (HH:MM NY)", c.flatBy, false)
        )
        col.addView(Ui.section(ctx, "La mia lista titoli"))
        watch = Ui.input(ctx, "Titoli separati da virgola", act.store.watchlist.joinToString(", "))
        watch.isSingleLine = false
        col.addView(watch)
        col.addView(Ui.button(ctx, "Salva") { save(c) })
        col.addView(Ui.button(ctx, "Azzera operazioni registrate", Ui.BAD) { act.store.clearLedger(); status.text = "Registro azzerato." })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        col.addView(Ui.spacer(ctx, 12))
        col.addView(Ui.muted(ctx, Ui.DISCLAIMER))
        col.addView(Ui.muted(ctx, "I dati vengono da Yahoo Finance (non ufficiale), Nasdaq Trader, SEC EDGAR e Clerk della Camera USA. L'app non invia mai ordini."))
        return scrolling(col)
    }

    private fun save(old: Config) {
        fun d(k: String, def: Double) = f[k]!!.text.toString().trim().replace(",", ".").toDoubleOrNull() ?: def
        val nc = old.copy(
            budget = d("budget", old.budget), cashBufferPct = d("buffer", old.cashBufferPct), maxPositionPct = d("pos", old.maxPositionPct),
            maxOrderUsd = d("order", old.maxOrderUsd), maxLossPerTrade = d("loss", old.maxLossPerTrade), maxDailyLoss = d("daily", old.maxDailyLoss),
            maxTradesPerDay = d("trades", old.maxTradesPerDay.toDouble()).toInt(), minRewardRisk = d("rr", old.minRewardRisk),
            noEntriesBefore = f["from"]!!.text.toString().trim().ifEmpty { old.noEntriesBefore },
            noEntriesAfter = f["to"]!!.text.toString().trim().ifEmpty { old.noEntriesAfter },
            flatBy = f["flat"]!!.text.toString().trim().ifEmpty { old.flatBy }
        )
        act.store.saveConfig(nc)
        act.store.secUserAgent = ua.text.toString()
        val w = watch.text.toString().split(",", " ", "\n").map { it.trim().uppercase() }.filter { it.isNotEmpty() }.distinct()
        if (w.isNotEmpty()) act.store.watchlist = w
        status.setTextColor(Ui.ACCENT); status.text = "Salvato."
    }
}
