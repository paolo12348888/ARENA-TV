package com.example.daytrader.engine

import java.time.LocalDateTime

/** Le tue regole (equivalente di trader/config.json). */
data class Config(
    val budget: Double = 5000.0,
    val cashBufferPct: Double = 10.0,
    val maxPositionPct: Double = 75.0,
    val maxOrderUsd: Double = 4000.0,
    val minOrderUsd: Double = 5.0,
    val maxLossPerTrade: Double = 50.0,
    val maxDailyLoss: Double = 150.0,
    val maxTradesPerDay: Int = 3,
    val minRewardRisk: Double = 1.0,
    val noEntriesBefore: String = "09:45",
    val noEntriesAfter: String = "15:30",
    val flatBy: String = "15:55",
    val blocked: List<String> = emptyList(),
    val pdtGuard: Boolean = false
)

data class SizeLimit(val name: String, val usd: Double, val per: Double, val shares: Int, val how: String, var binds: Boolean = false)

data class SizeResult(
    val symbol: String, val entry: Double, val stop: Double, val target: Double,
    val riskPerShare: Double, val rewardRisk: Double,
    val budget: Double, val cashBuffer: Double, val cashAvailable: Double,
    val limits: List<SizeLimit>, val qty: Int, val boundBy: String, val cost: Double, val maxLoss: Double,
    val refusal: String?
)

object Sizing {
    private const val EPS = 1e-9

    fun roundCent(x: Double) = Math.floor(x * 100 + 0.5 + EPS) / 100.0

    fun sharesFor(usd: Double, perShare: Double): Int {
        val u = Math.round(usd * 100); val p = Math.round(perShare * 100)
        if (p <= 0 || u <= 0) return 0
        return (u / p).toInt()
    }

    private fun money(x: Double) = "%,.2f $".format(x)

    /** Dimensiona un acquisto: la quantità è il minimo tra perdita massima, tetto di posizione, ordine massimo e liquidità. */
    fun sizeTrade(symbol: String, entryPlan: Double, stopIn: Double, targetIn: Double, cfg: Config, price: Double? = null, cash: Double? = null): SizeResult {
        val sym = symbol.trim().uppercase()
        if (sym.isEmpty()) throw EngineError("Manca il simbolo.")
        if (sym in cfg.blocked.map { it.uppercase() }) throw EngineError("$sym è nella tua lista dei titoli bloccati.")
        if (entryPlan <= 0 || stopIn <= 0 || targetIn <= 0) throw EngineError("Servono ingresso, stop e target positivi.")
        if (cfg.budget <= 0) throw EngineError("Imposta un budget nelle Impostazioni.")
        if (cfg.cashBufferPct < 0 || cfg.cashBufferPct >= 100) throw EngineError("La riserva di liquidità deve essere tra 0 e 100.")
        val ref = if (price != null && roundCent(price) > roundCent(entryPlan)) roundCent(price) else roundCent(entryPlan)
        val stop = roundCent(stopIn); val target = roundCent(targetIn)
        if (stop >= ref) throw EngineError("Lo stop ${money(stop)} non è sotto l'ingresso ${money(ref)}.")
        if (target <= ref) throw EngineError("Il target ${money(target)} non è sopra l'ingresso ${money(ref)}: il movimento è già avvenuto.")
        val riskC = Math.round((ref - stop) * 100).toInt()
        val rewardC = Math.round((target - ref) * 100).toInt()
        val risk = riskC / 100.0
        val buffer = Math.round(cfg.budget * cfg.cashBufferPct / 100.0 * 100) / 100.0
        var available = cfg.budget - buffer
        if (cash != null && cash - buffer < available - 0.005) available = cash - buffer
        available = maxOf(Math.round(available * 100) / 100.0, 0.0)

        val limits = ArrayList<SizeLimit>()
        if (cfg.maxLossPerTrade > 0) limits.add(SizeLimit("perdita massima", cfg.maxLossPerTrade, risk, sharesFor(cfg.maxLossPerTrade, risk), "${money(cfg.maxLossPerTrade)} / ${"%.2f".format(risk)} di rischio ad azione"))
        if (cfg.maxPositionPct > 0) {
            val cap = Math.round(cfg.budget * cfg.maxPositionPct / 100.0 * 100) / 100.0
            limits.add(SizeLimit("tetto di posizione", cap, ref, sharesFor(cap, ref), "${"%.0f".format(cfg.maxPositionPct)}% del budget = ${money(cap)} / ${"%.2f".format(ref)}"))
        }
        if (cfg.maxOrderUsd > 0) limits.add(SizeLimit("ordine massimo", cfg.maxOrderUsd, ref, sharesFor(cfg.maxOrderUsd, ref), "${money(cfg.maxOrderUsd)} / ${"%.2f".format(ref)}"))
        limits.add(SizeLimit("liquidità", available, ref, sharesFor(available, ref), "budget meno riserva = ${money(available)} / ${"%.2f".format(ref)}"))

        val qty = maxOf(0, limits.minOf { it.shares })
        val bound = limits.first { it.shares == qty }.name
        limits.forEach { it.binds = it.name == bound }
        val cost = Math.round(qty * ref * 100) / 100.0
        val loss = Math.round(qty * riskC.toDouble()) / 100.0
        var refusal: String? = null
        if (qty == 0) {
            refusal = if (bound == "perdita massima")
                "Una sola azione rischia ${money(risk)} (ingresso ${"%.2f".format(ref)} meno stop ${"%.2f".format(stop)}), più della tua perdita massima per operazione (${money(cfg.maxLossPerTrade)}). Nessun ordine: salta o scegli uno stop più vicino."
            else
                "Una azione di $sym costa ${money(ref)}, più del limite «$bound». Nessun ordine."
        } else if (cfg.minRewardRisk > 0 && rewardC < cfg.minRewardRisk * riskC - EPS) {
            refusal = "Rischio/rendimento %.2f (target %.2f, ingresso %.2f, stop %.2f) sotto il tuo minimo %s: il controllo del rischio lo bloccherebbe.".format(rewardC / riskC.toDouble(), target, ref, stop, cfg.minRewardRisk.toString())
        } else if (cost < cfg.minOrderUsd - 0.005) {
            refusal = "$qty azioni di $sym fanno ${money(cost)}, sotto il tuo ordine minimo di ${money(cfg.minOrderUsd)}."
        }
        return SizeResult(sym, ref, stop, target, risk, Num.pyRound2(rewardC / riskC.toDouble()), cfg.budget, buffer, available, limits, qty, bound, cost, loss, refusal)
    }
}

/** Un'operazione già registrata oggi (per i limiti giornalieri). */
data class LedgerEntry(val date: String, val symbol: String, val maxLoss: Double, val opened: Boolean = true)

data class RiskVerdict(val pass: Boolean, val blocks: List<String>, val warnings: List<String>, val notes: List<String>)

/** Controllo del rischio PRIMA dell'operazione: PASS o BLOCCO con il motivo (porting di trader-risk, solo acquisti). */
object Risk {
    private fun hhmm(v: String): Int? = TimeUtil.parseClock(v)

    fun windowCheck(now: LocalDateTime, cfg: Config): Pair<List<String>, List<String>> {
        val before = hhmm(cfg.noEntriesBefore)
        var after = hhmm(cfg.noEntriesAfter)
        if (before == null && after == null) return Pair(emptyList(), emptyList())
        val warns = ArrayList<String>()
        val d = now.toLocalDate()
        val t = TimeUtil.minutesOf(now)
        val closed = TimeUtil.closedReason(d)
        if (closed != null) return Pair(listOf("Finestra: oggi il mercato è chiuso ($closed)."), warns)
        val ds = d.toString()
        val close = TimeUtil.closeMin(ds)
        if (t < TimeUtil.OPEN_MIN || t >= close) {
            return Pair(listOf("Finestra: il mercato è chiuso adesso (%s a New York; la sessione va dalle 09:30 alle %s).".format(TimeUtil.clock24(t), TimeUtil.clock24(close))), warns)
        }
        if (TimeUtil.isEarly(ds) && after != null) {
            after -= 180
            warns.add("Chiusura anticipata alle 13:00 oggi: nessun nuovo ingresso dopo le ${TimeUtil.clock24(after)}.")
        }
        if (before != null && t < before) return Pair(listOf("Finestra: nessun nuovo ingresso prima delle ${TimeUtil.clock24(before)} a New York (adesso sono le ${TimeUtil.clock24(t)})."), warns)
        if (after != null && t > after) return Pair(listOf("Finestra: nessun nuovo ingresso dopo le ${TimeUtil.clock24(after)} a New York (adesso sono le ${TimeUtil.clock24(t)})."), warns)
        return Pair(emptyList(), warns)
    }

    fun check(size: SizeResult, cfg: Config, nowNy: LocalDateTime, todayEntries: List<LedgerEntry>, dayTradesLast5: Int = 0): RiskVerdict {
        val blocks = ArrayList<String>()
        val warns = ArrayList<String>()
        val notes = ArrayList<String>()
        val today = nowNy.toLocalDate().toString()
        val sym = size.symbol
        val qty = size.qty
        if (qty <= 0) blocks.add("Dimensione: nessuna azione acquistabile entro i tuoi limiti.")
        if (sym in cfg.blocked.map { it.uppercase() }) blocks.add("Bloccato: $sym è nella tua lista dei titoli bloccati.")
        val cost = size.entry * qty
        if (qty > 0 && cost < cfg.minOrderUsd - 0.005) blocks.add("Dimensione: l'ordine (%.2f $) è sotto il minimo (%.2f $).".format(cost, cfg.minOrderUsd))
        if (cfg.maxOrderUsd > 0 && cost > cfg.maxOrderUsd + 0.005) blocks.add("Dimensione: l'ordine (%.2f $) supera il massimo (%.2f $).".format(cost, cfg.maxOrderUsd))
        val cap = cfg.budget * cfg.maxPositionPct / 100.0
        if (cfg.maxPositionPct > 0 && cost > cap + 0.005) blocks.add("Posizione: %.2f $ superano il %.0f%% del budget (%.2f $).".format(cost, cfg.maxPositionPct, cap))
        val buffer = cfg.budget * cfg.cashBufferPct / 100.0
        if (cfg.budget - cost < buffer - 0.005) blocks.add("Liquidità: l'acquisto intaccherebbe la riserva (%.2f $) o richiederebbe margine.".format(buffer))
        if (size.stop >= size.entry) blocks.add("Stop: deve stare sotto l'ingresso.")
        val loss = qty * (size.entry - size.stop)
        if (cfg.maxLossPerTrade > 0 && loss > cfg.maxLossPerTrade + 0.005) blocks.add("Perdita: %.2f $ allo stop superano il tuo massimo per operazione (%.2f $).".format(loss, cfg.maxLossPerTrade))
        val risk = size.entry - size.stop
        if (risk > 0) {
            val rr = (size.target - size.entry) / risk
            if (cfg.minRewardRisk > 0 && rr < cfg.minRewardRisk - 1e-9) blocks.add("Rischio/rendimento: %.2f è sotto il tuo minimo (%s).".format(rr, cfg.minRewardRisk.toString()))
        }
        val todays = todayEntries.filter { it.date == today && it.opened }
        val usedLoss = todays.sumOf { it.maxLoss }
        if (cfg.maxDailyLoss > 0 && usedLoss + loss > cfg.maxDailyLoss + 0.005) {
            blocks.add("Perdita giornaliera: %.2f $ già impegnati oggi + %.2f $ di questa operazione superano il limite di %.2f $.".format(usedLoss, loss, cfg.maxDailyLoss))
        }
        if (cfg.maxTradesPerDay > 0 && todays.size >= cfg.maxTradesPerDay) blocks.add("Operazioni: hai già ${todays.size} ingressi oggi (massimo ${cfg.maxTradesPerDay}).")
        if (todays.any { it.symbol.uppercase() == sym }) blocks.add("Doppione: oggi hai già registrato un ingresso su $sym.")
        val (wb, ww) = windowCheck(nowNy, cfg)
        blocks.addAll(wb); warns.addAll(ww)
        if (cfg.pdtGuard && dayTradesLast5 + todays.size >= 3) blocks.add("PDT: già $dayTradesLast5 day trade negli ultimi 5 giorni di mercato (un quarto farebbe scattare la vecchia regola).")
        warns.add("Lo stop è un piano, non una garanzia: in un mercato veloce o con un gap può essere eseguito molto più in basso.")
        notes.add("Perdita massima allo stop: %.2f $; usati oggi %.2f $ su %.2f $.".format(loss, usedLoss, cfg.maxDailyLoss))
        return RiskVerdict(blocks.isEmpty(), blocks, warns, notes)
    }
}
