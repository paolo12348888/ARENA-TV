package com.example.daytrader.engine

import com.example.daytrader.engine.Json.dbl
import com.example.daytrader.engine.Json.list
import com.example.daytrader.engine.Json.map
import com.example.daytrader.engine.Json.str
import java.math.BigDecimal
import java.math.RoundingMode

class EngineError(message: String) : Exception(message)

/** Una candela da 5 minuti della sessione regolare (9:30-16:00, ora di New York). */
data class Bar(
    val date: String, val slot: Int, val start: String,
    val o: Double, val h: Double, val l: Double, val c: Double, val v: Double
)

data class ChartData(val symbol: String, val meta: Map<String, Any?>, val bars: List<Bar>, val granularity: String?)

object Num {
    /** Arrotonda al centesimo, metà verso l'alto. */
    fun cents(x: Double): Double = Math.floor(x * 100.0 + 0.5 + 1e-9) / 100.0

    /** Arrotonda per difetto al centesimo (lo stop di un acquisto va sotto). */
    fun floorCents(x: Double): Double = Math.floor(Math.round(x * 1e6) / 1e4 + 1e-9) / 100.0

    /** Arrotonda per eccesso al centesimo. */
    fun ceilCents(x: Double): Double = Math.ceil(Math.round(x * 1e6) / 1e4 - 1e-9) / 100.0

    /** round(x, 2) di Python (metà al pari sulla rappresentazione decimale). */
    fun pyRound2(x: Double): Double = BigDecimal(x.toString()).setScale(2, RoundingMode.HALF_EVEN).toDouble()

    fun pyRound(x: Double, d: Int): Double = BigDecimal(x.toString()).setScale(d, RoundingMode.HALF_EVEN).toDouble()
}

object Market {
    const val INTERVAL = 300
    const val SESSION_BARS = 78

    fun chartResult(text: String, sym: String): Map<String, Any?> {
        val doc = try { Json.parse(text).map() } catch (e: Exception) { null }
            ?: throw EngineError("Risposta di Yahoo non valida per $sym")
        val chart = doc["chart"].map() ?: throw EngineError("Risposta di Yahoo senza grafico per $sym")
        val err = chart["error"].map()
        if (err != null) {
            throw EngineError("Yahoo: " + (err["description"].str() ?: err["code"].str() ?: "errore") + " ($sym)")
        }
        val res = chart["result"].list()?.firstOrNull().map()
            ?: throw EngineError("Nessun dato per $sym")
        return res
    }

    /**
     * Candele da 5 minuti complete della sessione regolare. Scarta: prezzi mancanti,
     * candele fuori griglia (il tick in corso), candele non ancora chiuse e fuori orario.
     */
    fun parseBars(result: Map<String, Any?>, nowEpoch: Long): ChartData {
        val meta = result["meta"].map() ?: emptyMap()
        val stamps = result["timestamp"].list() ?: emptyList()
        val q = result["indicators"].map()?.get("quote").list()?.firstOrNull().map() ?: emptyMap()
        fun col(k: String) = q[k].list() ?: emptyList()
        val open = col("open"); val high = col("high"); val low = col("low"); val close = col("close"); val vol = col("volume")
        var asOf = nowEpoch
        val rmt = meta["regularMarketTime"].dbl()
        if (rmt != null && rmt.toLong() < asOf) asOf = rmt.toLong()
        val bars = java.util.TreeMap<Long, Bar>()
        for (i in stamps.indices) {
            val ts = stamps[i].dbl()?.toLong() ?: continue
            val o = open.getOrNull(i).dbl(); val h = high.getOrNull(i).dbl()
            val l = low.getOrNull(i).dbl(); val c = close.getOrNull(i).dbl()
            if (o == null || h == null || l == null || c == null) continue
            if (ts % INTERVAL != 0L) continue
            val ny = TimeUtil.toNy(ts)
            val mins = TimeUtil.minutesOf(ny) - TimeUtil.OPEN_MIN
            if (mins < 0 || mins >= SESSION_BARS * 5) continue
            if (ts + INTERVAL > asOf) continue
            val v = vol.getOrNull(i).dbl() ?: 0.0
            bars[ts] = Bar(ny.toLocalDate().toString(), mins / 5, TimeUtil.clock24(TimeUtil.minutesOf(ny)), o, h, l, c, v)
        }
        return ChartData(meta["symbol"].str() ?: "", meta, bars.values.toList(), meta["dataGranularity"].str())
    }

    /** {data: {slot: Bar}} */
    fun splitSessions(bars: List<Bar>): Map<String, Map<Int, Bar>> {
        val out = java.util.TreeMap<String, MutableMap<Int, Bar>>()
        for (b in bars) out.getOrPut(b.date) { HashMap() }[b.slot] = b
        return out
    }

    fun yahooSymbol(t: String) = t.trim().uppercase().replace(".", "-")

    fun chartPath(sym: String, range: String, interval: String) =
        "/v8/finance/chart/${yahooSymbol(sym)}?range=$range&interval=$interval"
}
