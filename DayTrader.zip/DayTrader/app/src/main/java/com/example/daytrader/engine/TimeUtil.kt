package com.example.daytrader.engine

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

/** Orari di New York, festività e chiusure anticipate NYSE (da nyse.com, come nel repository). */
object TimeUtil {
    val NY: ZoneId = ZoneId.of("America/New_York")
    const val OPEN_MIN = 9 * 60 + 30
    const val CLOSE_MIN = 16 * 60
    const val EARLY_MIN = 13 * 60

    val HOLIDAYS = mapOf(
        "2026-01-01" to "Capodanno", "2026-01-19" to "Martin Luther King", "2026-02-16" to "Presidents' Day",
        "2026-04-03" to "Venerdì Santo", "2026-05-25" to "Memorial Day", "2026-06-19" to "Juneteenth",
        "2026-07-03" to "Giorno dell'Indipendenza (osservato)", "2026-09-07" to "Labor Day",
        "2026-11-26" to "Thanksgiving", "2026-12-25" to "Natale",
        "2027-01-01" to "Capodanno", "2027-01-18" to "Martin Luther King", "2027-02-15" to "Presidents' Day",
        "2027-03-26" to "Venerdì Santo", "2027-05-31" to "Memorial Day", "2027-06-18" to "Juneteenth (osservato)",
        "2027-07-05" to "Giorno dell'Indipendenza (osservato)", "2027-09-06" to "Labor Day",
        "2027-11-25" to "Thanksgiving", "2027-12-24" to "Natale (osservato)"
    )
    val EARLY_CLOSE = setOf("2026-11-27", "2026-12-24", "2027-11-26")

    fun toNy(epochSec: Long): LocalDateTime = LocalDateTime.ofInstant(Instant.ofEpochSecond(epochSec), NY)
    fun nowNy(): LocalDateTime = LocalDateTime.now(NY)

    fun minutesOf(t: LocalDateTime) = t.hour * 60 + t.minute

    fun isEarly(date: String) = date in EARLY_CLOSE
    fun closeMin(date: String) = if (isEarly(date)) EARLY_MIN else CLOSE_MIN

    /** null se è un giorno di mercato, altrimenti il motivo. */
    fun closedReason(date: LocalDate): String? {
        if (date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY) return "weekend"
        return HOLIDAYS[date.toString()]
    }

    fun clock12(mins: Int): String {
        val h = mins / 60
        val m = mins % 60
        val ap = if (h < 12) "AM" else "PM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, m, ap)
    }

    fun clock24(mins: Int) = "%02d:%02d".format(mins / 60, mins % 60)

    /** "HH:MM" -> minuti dalla mezzanotte, oppure null. */
    fun parseClock(t: String?): Int? {
        val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire((t ?: "").trim()) ?: return null
        val h = m.groupValues[1].toInt()
        val mm = m.groupValues[2].toInt()
        if (h > 23 || mm > 59) return null
        return h * 60 + mm
    }

    fun epochOf(ny: LocalDateTime): Long = ny.atZone(NY).toEpochSecond()
    fun utcOf(epochSec: Long): LocalDateTime = LocalDateTime.ofEpochSecond(epochSec, 0, ZoneOffset.UTC)
}
