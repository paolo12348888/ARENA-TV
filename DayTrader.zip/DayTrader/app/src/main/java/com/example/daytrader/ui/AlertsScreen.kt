package com.example.daytrader.ui

import android.content.Intent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import com.example.daytrader.AlertRunner
import com.example.daytrader.AlertService
import com.example.daytrader.MainActivity
import com.example.daytrader.engine.AlertRule

/** Avvisi di prezzo e promemoria, con controllo in primo piano ogni minuto. */
class AlertsScreen(act: MainActivity) : Screen(act) {
    private lateinit var kind: Spinner
    private lateinit var sym: EditText
    private lateinit var value: EditText
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val kinds = listOf("above", "below", "pct_move", "opening_bell")
    private val names = listOf("Sale sopra un prezzo", "Scende sotto un prezzo", "Movimento % in giornata", "Campanella d'apertura")

    override fun build(): View {
        val col = LinearLayout(ctx)
        col.addView(Ui.title(ctx, "Avvisi"))
        col.addView(Ui.muted(ctx, "Con il controllo attivo l'app guarda i prezzi ogni minuto mentre Wall Street è aperta e ti manda una notifica. Android può fermarlo per risparmiare batteria: non è un servizio garantito."))
        col.addView(Ui.section(ctx, "Nuovo avviso"))
        kind = spinner(names)
        sym = Ui.input(ctx, "Titolo (es. TSLA)", "")
        value = Ui.input(ctx, "Prezzo o percentuale", "", number = true)
        col.addView(kind); col.addView(sym); col.addView(value)
        col.addView(Ui.button(ctx, "Aggiungi") { add() })
        col.addView(Ui.section(ctx, "Controllo"))
        col.addView(Ui.button(ctx, "Attiva / disattiva controllo continuo") { toggle() })
        col.addView(Ui.button(ctx, "Controlla ora", Ui.WARN) { now() })
        status = Ui.muted(ctx, "", 13f)
        col.addView(status)
        col.addView(Ui.section(ctx, "Avvisi attivi"))
        list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        return scrolling(col)
    }

    override fun onShown() { refresh() }

    private fun add() {
        val k = kinds[kind.selectedItemPosition]
        val s = sym.text.toString().trim().uppercase()
        val v = num(value.text.toString())
        val id = "m-" + System.currentTimeMillis()
        val rule = when (k) {
            "opening_bell" -> AlertRule(id, k, label = "Wall Street è aperta")
            "pct_move" -> { if (s.isEmpty() || v == null) return fail("Servono titolo e percentuale."); AlertRule(id, k, s, pct = v, rearm = false) }
            else -> { if (s.isEmpty() || v == null) return fail("Servono titolo e prezzo."); AlertRule(id, k, s, price = v) }
        }
        act.store.saveRules(act.store.rules() + rule)
        status.setTextColor(Ui.ACCENT); status.text = "Avviso aggiunto."
        refresh()
    }

    private fun fail(s: String) { status.setTextColor(Ui.BAD); status.text = s }

    private fun toggle() {
        val on = !act.store.monitoring
        act.store.monitoring = on
        val i = Intent(act, AlertService::class.java)
        try {
            if (on) act.startForegroundService(i) else act.stopService(i)
            status.setTextColor(Ui.ACCENT)
            status.text = if (on) "Controllo attivo (compare una notifica fissa)." else "Controllo fermato."
        } catch (e: Exception) {
            act.store.monitoring = false
            fail("Impossibile avviare il servizio: ${e.message}")
        }
    }

    private fun now() {
        status.setTextColor(Ui.MUTED); status.text = "Controllo…"
        act.bg {
            try {
                val rings = AlertRunner.runOnce(act, true)
                act.ui { status.text = if (rings.isEmpty()) "Nessun avviso è scattato." else rings.joinToString("\n") { it.title + " — " + it.body }; refresh() }
            } catch (e: Exception) { act.ui { fail(e.message ?: "errore") } }
        }
    }

    private fun refresh() {
        list.removeAllViews()
        val rules = act.store.rules()
        if (rules.isEmpty()) list.addView(Ui.muted(ctx, "Nessun avviso."))
        for (r in rules) {
            val c = Ui.card(ctx)
            val d = when (r.type) {
                "above", "target" -> "${r.symbol} sopra ${r.price}"
                "below", "stop" -> "${r.symbol} sotto ${r.price}"
                "pct_move" -> "${r.symbol} muove di ${r.pct}%"
                "time" -> r.label.ifEmpty { "Promemoria ${r.at}" }
                else -> r.label.ifEmpty { r.type }
            }
            c.addView(Ui.text(ctx, d, 14f, Ui.TEXT, true))
            if (r.note.isNotEmpty()) c.addView(Ui.muted(ctx, r.note))
            if (r.date.isNotEmpty()) c.addView(Ui.muted(ctx, "Valido il ${r.date}"))
            c.addView(Ui.button(ctx, "Elimina", Ui.BAD) {
                act.store.saveRules(act.store.rules().filter { it.id != r.id }); refresh()
            })
            list.addView(c)
        }
    }
}
