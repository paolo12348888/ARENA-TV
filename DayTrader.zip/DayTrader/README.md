# Day Trader (Android)

Versione per telefono degli 11 strumenti di day-trader-skill (MIT, Jake Schincariol).
Scansione, operazione (entrata, uscita, dimensione, rischio, Time Machine), notizie, bilanci, dichiarazioni della Camera USA, avvisi.

L'app NON invia mai ordini. Strumento educativo, non consulenza finanziaria.
Dati: Yahoo Finance (non ufficiale), Nasdaq Trader, SEC EDGAR, Clerk della Camera USA.
Per notizie 8-K e bilanci inserisci nome ed email in Impostazioni.
